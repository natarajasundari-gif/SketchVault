import os
from flask import Flask, jsonify
from dotenv import load_dotenv
from flask_jwt_extended.exceptions import CSRFError

from app.config import Config
from app.extensions import db, migrate, jwt, bcrypt, cors

load_dotenv()


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    bcrypt.init_app(app)
    # credentials must be allowed since auth uses httpOnly cookies,
    # not an Authorization header — so the frontend origin must be
    # explicit rather than "*".
    cors.init_app(app, supports_credentials=True, origins=[app.config["FRONTEND_ORIGIN"]])

    _register_jwt_error_handlers(app)

    # Models must be imported (even unused) before migrations run,
    # so Flask-Migrate knows about every table.
    from app.models import user, artwork, tag, progress_entry  # noqa: F401

    from app.routes.health import health_bp
    from app.routes.uploads import uploads_bp
    from app.routes.auth import auth_bp
    from app.routes.artworks import artworks_bp
    from app.routes.progress import progress_bp
    from app.routes.tags import tags_bp
    from app.routes.users import users_bp

    app.register_blueprint(health_bp, url_prefix="/api/health")
    app.register_blueprint(uploads_bp, url_prefix="/api/uploads")
    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(artworks_bp, url_prefix="/api/artworks")
    app.register_blueprint(progress_bp, url_prefix="/api")
    app.register_blueprint(tags_bp, url_prefix="/api/tags")
    app.register_blueprint(users_bp, url_prefix="/api/users")

    @app.errorhandler(404)
    def not_found(_e):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(413)
    def too_large(_e):
        return jsonify({"error": "File is too large"}), 413

    @app.errorhandler(500)
    def server_error(_e):
        return jsonify({"error": "Something went wrong on our end"}), 500

    @app.errorhandler(CSRFError)
    def csrf_error(_e):
        return jsonify({"error": "Your session could not be verified. Please refresh and try again."}), 401

    return app


def _register_jwt_error_handlers(app):
    """Turn Flask-JWT-Extended's default responses into the same
    plain-JSON shape the rest of the API uses, so the frontend never
    has to special-case auth errors vs. any other error.
    """

    @jwt.unauthorized_loader
    def _missing_token(_reason):
        return jsonify({"error": "Please log in to continue"}), 401

    @jwt.invalid_token_loader
    def _invalid_token(_reason):
        return jsonify({"error": "Your session is invalid. Please log in again."}), 401

    @jwt.expired_token_loader
    def _expired_token(_header, _payload):
        return jsonify({"error": "Your session has expired. Please log in again."}), 401

    @jwt.needs_fresh_token_loader
    def _needs_fresh(_header, _payload):
        return jsonify({"error": "Please log in again to continue."}), 401

    @jwt.revoked_token_loader
    def _revoked_token(_header, _payload):
        return jsonify({"error": "Your session has ended. Please log in again."}), 401
