from flask import Blueprint, request, jsonify, make_response, current_app
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    set_access_cookies,
    set_refresh_cookies,
    unset_jwt_cookies,
    jwt_required,
    get_jwt_identity,
)
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

from app.extensions import db, bcrypt
from app.models.user import User
from app.utils.validators import validate_email, validate_password

auth_bp = Blueprint("auth", "auth")


def _issue_session(user, status=200):
    """Create a fresh access+refresh token pair and attach them as
    httpOnly cookies on the response. This is the one place tokens
    get minted — register, login, and (implicitly) refresh all funnel
    through it or something equivalent, so cookie settings never
    drift out of sync between the two auth entry points.
    """
    identity = str(user.id)
    access_token = create_access_token(identity=identity)
    refresh_token = create_refresh_token(identity=identity)
    resp = make_response(jsonify({"user": user.to_dict()}), status)
    set_access_cookies(resp, access_token)
    set_refresh_cookies(resp, refresh_token)
    return resp


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    fields = {}
    if not name:
        fields["name"] = "Name is required"
    if not validate_email(email):
        fields["email"] = "Enter a valid email address"
    password_ok, password_msg = validate_password(password)
    if not password_ok:
        fields["password"] = password_msg
    if fields:
        return jsonify({"error": "Please fix the highlighted fields", "fields": fields}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({
            "error": "An account with this email already exists",
            "fields": {"email": "Already registered"},
        }), 409

    user = User(
        name=name,
        email=email,
        password_hash=bcrypt.generate_password_hash(password).decode("utf-8"),
    )
    db.session.add(user)
    db.session.commit()

    return _issue_session(user, status=201)


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    user = User.query.filter_by(email=email).first()
    if not user or not bcrypt.check_password_hash(user.password_hash, password):
        # Deliberately identical message for "no such user" and "wrong
        # password" — distinguishing them tells an attacker which
        # emails have accounts.
        return jsonify({"error": "Incorrect email or password"}), 401

    return _issue_session(user)


@auth_bp.post("/logout")
def logout():
    resp = make_response(jsonify({"message": "Logged out"}))
    unset_jwt_cookies(resp)
    return resp


@auth_bp.get("/me")
@jwt_required()
def me():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "Session is no longer valid"}), 401
    return jsonify({"user": user.to_dict()})


@auth_bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    access_token = create_access_token(identity=get_jwt_identity())
    resp = make_response(jsonify({"message": "Session refreshed"}))
    set_access_cookies(resp, access_token)
    return resp


def _reset_serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="password-reset")


@auth_bp.post("/forgot-password")
def forgot_password():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    user = User.query.filter_by(email=email).first()

    # Same response whether or not the account exists — otherwise this
    # endpoint becomes a way to check who has an account here.
    body = {"message": "If that email has an account, a reset link has been generated."}

    if user:
        token = _reset_serializer().dumps({"user_id": user.id})
        # No email provider is wired up yet — see README "known
        # limitations". The link is handed back directly so the flow
        # is usable in local development; swapping in real email
        # delivery later means changing only this block.
        body["dev_reset_url"] = f"/reset-password?token={token}"

    return jsonify(body)


@auth_bp.post("/reset-password")
def reset_password():
    data = request.get_json(silent=True) or {}
    token = data.get("token") or ""
    new_password = data.get("password") or ""

    password_ok, password_msg = validate_password(new_password)
    if not password_ok:
        return jsonify({"error": password_msg}), 400

    try:
        payload = _reset_serializer().loads(token, max_age=3600)
    except SignatureExpired:
        return jsonify({"error": "This reset link has expired. Request a new one."}), 400
    except BadSignature:
        return jsonify({"error": "This reset link is invalid."}), 400

    user = User.query.get(payload.get("user_id"))
    if not user:
        return jsonify({"error": "This reset link is invalid."}), 400

    user.password_hash = bcrypt.generate_password_hash(new_password).decode("utf-8")
    db.session.commit()
    return jsonify({"message": "Password updated — you can now log in."})
