from flask import Blueprint, jsonify

health_bp = Blueprint("health", "health")


@health_bp.get("/")
def health_check():
    return jsonify({"status": "ok", "service": "sketchvault-api"})
