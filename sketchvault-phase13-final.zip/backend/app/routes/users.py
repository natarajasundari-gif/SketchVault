from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db, bcrypt
from app.models.user import User

users_bp = Blueprint("users", "users")

_MIN_PASSWORD = 8


def _current_user():
    return User.query.get(int(get_jwt_identity()))


# ── GET profile ───────────────────────────────────────────────────────────────

@users_bp.get("/me")
@jwt_required()
def get_profile():
    user = _current_user()
    if not user:
        return jsonify({"error": "User not found"}), 404
    return jsonify({"user": user.to_dict()})


# ── Update name / email ───────────────────────────────────────────────────────

@users_bp.put("/me")
@jwt_required()
def update_profile():
    user = _current_user()
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json(silent=True) or {}
    fields = {}

    if "name" in data:
        name = (data["name"] or "").strip()
        if not name:
            fields["name"] = "Name is required"
        else:
            user.name = name

    if "email" in data:
        email = (data["email"] or "").strip().lower()
        if not email or "@" not in email:
            fields["email"] = "Please enter a valid email address"
        else:
            existing = User.query.filter(
                User.email == email, User.id != user.id
            ).first()
            if existing:
                fields["email"] = "This email is already in use"
            else:
                user.email = email

    if fields:
        return jsonify({"error": "Please fix the highlighted fields", "fields": fields}), 400

    db.session.commit()
    return jsonify({"user": user.to_dict()})


# ── Change password ───────────────────────────────────────────────────────────

@users_bp.put("/me/password")
@jwt_required()
def change_password():
    user = _current_user()
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json(silent=True) or {}
    current = data.get("current_password") or ""
    new = data.get("new_password") or ""

    fields = {}
    if not current:
        fields["current_password"] = "Current password is required"
    elif not bcrypt.check_password_hash(user.password_hash, current):
        fields["current_password"] = "That password is incorrect"

    if not new:
        fields["new_password"] = "New password is required"
    elif len(new) < _MIN_PASSWORD:
        fields["new_password"] = f"Password must be at least {_MIN_PASSWORD} characters"
    elif new == current:
        fields["new_password"] = "New password must be different from your current one"

    if fields:
        return jsonify({"error": "Please fix the highlighted fields", "fields": fields}), 400

    user.password_hash = bcrypt.generate_password_hash(new).decode("utf-8")
    db.session.commit()
    return jsonify({"message": "Password updated"})


# ── Delete account ────────────────────────────────────────────────────────────

@users_bp.delete("/me")
@jwt_required()
def delete_account():
    user = _current_user()
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json(silent=True) or {}
    password = data.get("password") or ""

    if not password or not bcrypt.check_password_hash(user.password_hash, password):
        return jsonify({
            "error": "Please fix the highlighted fields",
            "fields": {"password": "Incorrect password"},
        }), 400

    # Cascade delete is on the User → Artwork relationship, and
    # Artwork → ProgressEntry too, so this removes everything.
    # Image files on disk are NOT cleaned up here (they're orphaned)
    # — a background task or cron job handles that in production.
    db.session.delete(user)
    db.session.commit()
    return jsonify({"message": "Account deleted"})


# ── Upload / remove avatar ────────────────────────────────────────────────────

@users_bp.post("/me/avatar")
@jwt_required()
def upload_avatar():
    user = _current_user()
    if not user:
        return jsonify({"error": "User not found"}), 404

    from app.utils.validators import validate_image
    from app.services.storage import storage

    image_file = request.files.get("avatar")
    if not image_file or not image_file.filename:
        return jsonify({"error": "No image provided", "fields": {"avatar": "Please choose an image"}}), 400

    is_valid, error = validate_image(image_file)
    if not is_valid:
        return jsonify({"error": error, "fields": {"avatar": error}}), 400

    # Delete old avatar before saving new one
    if user.avatar:
        storage.delete(user.avatar)

    user.avatar = storage.save(image_file, "avatars")
    db.session.commit()
    return jsonify({"user": user.to_dict()})


@users_bp.delete("/me/avatar")
@jwt_required()
def remove_avatar():
    user = _current_user()
    if not user:
        return jsonify({"error": "User not found"}), 404

    from app.services.storage import storage

    if user.avatar:
        storage.delete(user.avatar)
        user.avatar = None
        db.session.commit()

    return jsonify({"user": user.to_dict()})
