from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required

from app.models.tag import Tag

tags_bp = Blueprint("tags", "tags")


@tags_bp.get("/")
@jwt_required()
def list_tags():
    """All tags in the system, for the tag-input's suggestions.
    Tags aren't user-scoped (they're just normalized labels — see
    the Phase 1 schema notes), so this list is shared.
    """
    tags = Tag.query.order_by(Tag.name).all()
    return jsonify({"tags": [t.to_dict() for t in tags]})
