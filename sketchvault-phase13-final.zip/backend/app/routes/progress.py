from datetime import datetime

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required

from app.extensions import db
from app.models.progress_entry import ProgressEntry
from app.utils.decorators import require_artwork_owner
from app.utils.validators import validate_image
from app.services.storage import storage

progress_bp = Blueprint("progress", "progress")


def _clamp(val, lo=0, hi=100) -> int:
    try:
        return max(lo, min(hi, int(val)))
    except (TypeError, ValueError):
        return lo


def _clamp_f(val, lo=0.0, hi=1.0):
    try:
        return max(lo, min(hi, float(val)))
    except (TypeError, ValueError):
        return None


def _parse_crop(form):
    """Read normalised 0-1 crop centre + dimensions from a multipart form.
    Returns (cx, cy, w, h) or (None, None, None, None) if absent/malformed."""
    cx = _clamp_f(form.get("crop_cx"))
    cy = _clamp_f(form.get("crop_cy"))
    w  = _clamp_f(form.get("crop_w"))
    h  = _clamp_f(form.get("crop_h"))
    if None in (cx, cy, w, h):
        return None, None, None, None
    return cx, cy, w, h


def _sync_artwork(artwork, entry):
    """Keep the parent artwork's progress/status in sync with the most
    recent progress entry after any add, edit, or delete."""
    latest = (
        ProgressEntry.query
        .filter_by(artwork_id=artwork.id)
        .order_by(ProgressEntry.created_at.desc())
        .first()
    )
    if latest:
        artwork.progress = latest.progress
        artwork.status = latest.stage
    artwork.updated_at = datetime.utcnow()


# ── List ──────────────────────────────────────────────────────────────────────

@progress_bp.get("/artworks/<int:artwork_id>/progress")
@jwt_required()
@require_artwork_owner
def list_entries(artwork):
    entries = (
        ProgressEntry.query
        .filter_by(artwork_id=artwork.id)
        .order_by(ProgressEntry.created_at.asc())
        .all()
    )
    return jsonify({"entries": [e.to_dict() for e in entries]})


# ── Add ───────────────────────────────────────────────────────────────────────

@progress_bp.post("/artworks/<int:artwork_id>/progress")
@jwt_required()
@require_artwork_owner
def add_entry(artwork):
    stage = (request.form.get("stage") or "").strip()
    if not stage:
        return jsonify({
            "error": "Please fix the highlighted fields",
            "fields": {"stage": "Stage name is required"},
        }), 400

    image_file = request.files.get("image")
    if not image_file or not image_file.filename:
        return jsonify({
            "error": "Please fix the highlighted fields",
            "fields": {"image": "An image is required for each progress entry"},
        }), 400

    is_valid, error = validate_image(image_file)
    if not is_valid:
        return jsonify({"error": error, "fields": {"image": error}}), 400

    image_key = storage.save(image_file, f"progress/{artwork.id}")
    cx, cy, w, h = _parse_crop(request.form)

    entry = ProgressEntry(
        artwork_id=artwork.id,
        image=image_key,
        stage=stage,
        progress=_clamp(request.form.get("progress", artwork.progress)),
        note=(request.form.get("note") or "").strip() or None,
        crop_cx=cx, crop_cy=cy, crop_w=w, crop_h=h,
    )
    db.session.add(entry)
    _sync_artwork(artwork, entry)
    db.session.commit()
    return jsonify({"entry": entry.to_dict(), "artwork": artwork.to_dict()}), 201


# ── Edit ──────────────────────────────────────────────────────────────────────

@progress_bp.put("/artworks/<int:artwork_id>/progress/<int:entry_id>")
@jwt_required()
@require_artwork_owner
def update_entry(artwork, entry_id):
    entry = ProgressEntry.query.filter_by(id=entry_id, artwork_id=artwork.id).first()
    if not entry:
        return jsonify({"error": "Progress entry not found"}), 404

    if "stage" in request.form:
        stage = (request.form.get("stage") or "").strip()
        if not stage:
            return jsonify({
                "error": "Please fix the highlighted fields",
                "fields": {"stage": "Stage name is required"},
            }), 400
        entry.stage = stage

    if "progress" in request.form:
        entry.progress = _clamp(request.form.get("progress"))

    if "note" in request.form:
        entry.note = (request.form.get("note") or "").strip() or None

    # Optional image replacement — delete old file, store new one.
    new_image = request.files.get("image")
    if new_image and new_image.filename:
        is_valid, error = validate_image(new_image)
        if not is_valid:
            return jsonify({"error": error, "fields": {"image": error}}), 400
        old_key = entry.image
        entry.image = storage.save(new_image, f"progress/{artwork.id}")
        storage.delete(old_key)

    # Update crop if provided alongside a new image OR as a standalone update.
    if "crop_cx" in request.form:
        cx, cy, w, h = _parse_crop(request.form)
        entry.crop_cx, entry.crop_cy, entry.crop_w, entry.crop_h = cx, cy, w, h

    _sync_artwork(artwork, entry)
    db.session.commit()
    return jsonify({"entry": entry.to_dict(), "artwork": artwork.to_dict()})


# ── Delete ────────────────────────────────────────────────────────────────────

@progress_bp.delete("/artworks/<int:artwork_id>/progress/<int:entry_id>")
@jwt_required()
@require_artwork_owner
def delete_entry(artwork, entry_id):
    entry = ProgressEntry.query.filter_by(id=entry_id, artwork_id=artwork.id).first()
    if not entry:
        return jsonify({"error": "Progress entry not found"}), 404

    storage.delete(entry.image)
    db.session.delete(entry)

    remaining = (
        ProgressEntry.query
        .filter_by(artwork_id=artwork.id)
        .filter(ProgressEntry.id != entry.id)
        .order_by(ProgressEntry.created_at.desc())
        .first()
    )
    if remaining:
        artwork.progress = remaining.progress
        artwork.status = remaining.stage
    artwork.updated_at = datetime.utcnow()

    db.session.commit()
    return jsonify({"message": "Progress entry deleted", "artwork": artwork.to_dict()})
