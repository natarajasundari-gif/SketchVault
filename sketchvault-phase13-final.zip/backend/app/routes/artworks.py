from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.artwork import Artwork
from app.models.tag import Tag
from app.utils.decorators import require_artwork_owner
from app.utils.validators import validate_image
from app.services.storage import storage

artworks_bp = Blueprint("artworks", "artworks")

_SORT_COLUMNS = {
    "recent_updated": Artwork.updated_at.desc(),
    "recent_created": Artwork.created_at.desc(),
    "alphabetical": Artwork.title.asc(),
    "progress": Artwork.progress.desc(),
}


def _get_or_create_tags(raw_tags: str) -> list[Tag]:
    """Turn a comma-separated string into Tag rows, reusing an
    existing tag (case-insensitively) instead of creating a
    near-duplicate — "Portrait" and "portrait" are the same tag.
    """
    names = [t.strip() for t in raw_tags.split(",")] if raw_tags else []
    tags, seen = [], set()
    for name in names:
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        tag = Tag.query.filter(db.func.lower(Tag.name) == name.lower()).first()
        if not tag:
            tag = Tag(name=name)
            db.session.add(tag)
        tags.append(tag)
    return tags


def _clamp_progress(raw) -> int:
    try:
        return max(0, min(100, int(raw)))
    except (TypeError, ValueError):
        return 0


@artworks_bp.get("/")
@jwt_required()
def list_artworks():
    user_id = int(get_jwt_identity())
    query = Artwork.query.filter_by(user_id=user_id)

    search = request.args.get("q", "").strip()
    if search:
        like = f"%{search}%"
        query = query.filter(
            db.or_(Artwork.title.ilike(like), Artwork.description.ilike(like))
        )

    for field, column in (("medium", Artwork.medium), ("category", Artwork.category), ("status", Artwork.status)):
        value = request.args.get(field)
        if value:
            query = query.filter(column == value)

    tag = request.args.get("tag")
    if tag:
        query = query.join(Artwork.tags).filter(db.func.lower(Tag.name) == tag.lower())

    completed = request.args.get("completed")
    if completed == "true":
        query = query.filter(Artwork.progress >= 100)
    elif completed == "false":
        query = query.filter(Artwork.progress < 100)

    sort_key = request.args.get("sort", "recent_updated")
    query = query.order_by(_SORT_COLUMNS.get(sort_key, _SORT_COLUMNS["recent_updated"]))

    artworks = query.all()
    # Total progress entries across all the user's artworks — cheap
    # aggregate, no N+1. Used by the dashboard stats card.
    from app.models.progress_entry import ProgressEntry
    total_entries = (
        db.session.query(db.func.count(ProgressEntry.id))
        .join(Artwork, ProgressEntry.artwork_id == Artwork.id)
        .filter(Artwork.user_id == user_id)
        .scalar()
    ) or 0
    return jsonify({"artworks": [a.to_dict() for a in artworks], "total_entries": total_entries})


@artworks_bp.post("/")
@jwt_required()
def create_artwork():
    user_id = int(get_jwt_identity())
    data = request.form

    title = (data.get("title") or "").strip()
    if not title:
        return jsonify({
            "error": "Please fix the highlighted fields",
            "fields": {"title": "Title is required"},
        }), 400

    artwork = Artwork(
        user_id=user_id,
        title=title,
        description=(data.get("description") or "").strip() or None,
        medium=(data.get("medium") or "Other").strip(),
        category=(data.get("category") or "Other").strip(),
        status=(data.get("status") or "Sketching").strip(),
        progress=_clamp_progress(data.get("progress", 0)),
    )
    artwork.tags = _get_or_create_tags(data.get("tags", ""))

    cover_image = request.files.get("cover_image")
    if cover_image and cover_image.filename:
        is_valid, error = validate_image(cover_image)
        if not is_valid:
            return jsonify({"error": error, "fields": {"cover_image": error}}), 400
        artwork.cover_image = storage.save(cover_image, "covers")

    db.session.add(artwork)
    db.session.commit()
    return jsonify({"artwork": artwork.to_dict()}), 201


@artworks_bp.get("/<int:artwork_id>")
@jwt_required()
@require_artwork_owner
def get_artwork(artwork):
    return jsonify({"artwork": artwork.to_dict(include_entries=True)})


@artworks_bp.put("/<int:artwork_id>")
@jwt_required()
@require_artwork_owner
def update_artwork(artwork):
    data = request.form

    if "title" in data:
        title = (data.get("title") or "").strip()
        if not title:
            return jsonify({
                "error": "Please fix the highlighted fields",
                "fields": {"title": "Title is required"},
            }), 400
        artwork.title = title

    if "description" in data:
        artwork.description = (data.get("description") or "").strip() or None
    if "medium" in data:
        artwork.medium = (data.get("medium") or artwork.medium).strip()
    if "category" in data:
        artwork.category = (data.get("category") or artwork.category).strip()
    if "status" in data:
        artwork.status = (data.get("status") or artwork.status).strip()
    if "progress" in data:
        artwork.progress = _clamp_progress(data.get("progress"))
    if "tags" in data:
        artwork.tags = _get_or_create_tags(data.get("tags", ""))

    cover_image = request.files.get("cover_image")
    if cover_image and cover_image.filename:
        is_valid, error = validate_image(cover_image)
        if not is_valid:
            return jsonify({"error": error, "fields": {"cover_image": error}}), 400
        old_key = artwork.cover_image
        artwork.cover_image = storage.save(cover_image, "covers")
        if old_key:
            storage.delete(old_key)

    db.session.commit()
    return jsonify({"artwork": artwork.to_dict()})


@artworks_bp.delete("/<int:artwork_id>")
@jwt_required()
@require_artwork_owner
def delete_artwork(artwork):
    if artwork.cover_image:
        storage.delete(artwork.cover_image)
    for entry in artwork.progress_entries:
        if entry.image:
            storage.delete(entry.image)

    db.session.delete(artwork)
    db.session.commit()
    return jsonify({"message": "Artwork deleted"})
