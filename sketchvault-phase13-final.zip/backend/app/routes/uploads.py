from flask import Blueprint, send_from_directory, current_app, request, make_response

uploads_bp = Blueprint("uploads", "uploads")


# Serves locally-stored images by their storage key, e.g.
# /api/uploads/covers/<uuid>.jpg — see app/services/storage.py,
# which is the only other place that needs to know this path shape.
#
# We manually set Access-Control-Allow-Origin here because
# send_from_directory returns a static file response that bypasses
# the Flask-CORS WSGI middleware, so images loaded from the React
# dev server (a different port) would otherwise be blocked.
@uploads_bp.get("/<path:key>")
def serve_upload(key):
    resp = make_response(send_from_directory(current_app.config["UPLOAD_FOLDER"], key))
    origin = request.headers.get("Origin", "")
    allowed = current_app.config.get("FRONTEND_ORIGIN", "")
    if origin == allowed:
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Access-Control-Allow-Credentials"] = "true"
        resp.headers["Vary"] = "Origin"
    return resp
