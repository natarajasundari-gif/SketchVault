from functools import wraps
from flask import jsonify
from flask_jwt_extended import get_jwt_identity

from app.models.artwork import Artwork


def require_artwork_owner(view_func):
    """Load the artwork by `artwork_id` from the URL and confirm the
    current JWT-identified user owns it, before the view runs.

    This is the single place the "can't touch someone else's artwork
    by editing the URL" rule is enforced — every artwork/progress
    route below just uses this decorator instead of re-checking
    ownership by hand.
    """

    @wraps(view_func)
    def wrapper(artwork_id, *args, **kwargs):
        artwork = Artwork.query.get(artwork_id)
        if artwork is None:
            return jsonify({"error": "Artwork not found"}), 404
        if artwork.user_id != int(get_jwt_identity()):
            return jsonify({"error": "You don't have access to this artwork"}), 403
        return view_func(artwork, *args, **kwargs)

    return wrapper
