import re
from flask import current_app
from PIL import Image

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_email(email: str) -> bool:
    return bool(email) and bool(_EMAIL_RE.match(email))


def validate_password(password: str) -> tuple[bool, str]:
    if not password or len(password) < 8:
        return False, "Password must be at least 8 characters"
    return True, ""


def validate_image(file_storage) -> tuple[bool, str]:
    """Check a Flask-Werkzeug FileStorage before it's saved anywhere.

    Returns (is_valid, error_message). Checks the file extension AND
    sniffs the real image data with Pillow — a renamed .exe with a
    .jpg extension will fail the second check even if it passes the
    first.
    """
    if not file_storage or file_storage.filename == "":
        return False, "No file was provided"

    ext = file_storage.filename.rsplit(".", 1)[-1].lower() if "." in file_storage.filename else ""
    allowed = current_app.config["ALLOWED_IMAGE_EXTENSIONS"]
    if ext not in allowed:
        return False, f"Unsupported file type. Allowed: {', '.join(sorted(allowed))}"

    try:
        image = Image.open(file_storage.stream)
        image.verify()
        file_storage.stream.seek(0)
    except Exception:
        return False, "File is not a valid image"

    return True, ""
