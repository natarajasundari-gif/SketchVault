"""
Image storage abstraction.

Every route that needs to save or serve an uploaded image talks to
`storage` (the instance at the bottom of this file), never to the
filesystem directly. That's what lets a cloud backend (S3, Cloudinary,
etc.) replace LocalStorageService later by writing one new class that
implements the same three methods — no changes anywhere else.
"""

import os
import uuid
from abc import ABC, abstractmethod

from flask import current_app, url_for


class StorageService(ABC):
    @abstractmethod
    def save(self, file_storage, subfolder: str) -> str:
        """Save an uploaded file, return the key used to retrieve it later."""

    @abstractmethod
    def url_for_key(self, key: str) -> str:
        """Return a URL the frontend can load the image from."""

    @abstractmethod
    def delete(self, key: str) -> None:
        """Remove a stored image. Safe to call on a missing key."""


class LocalStorageService(StorageService):
    def save(self, file_storage, subfolder: str) -> str:
        ext = file_storage.filename.rsplit(".", 1)[-1].lower()
        # Generated filename — never trust the name the client sent.
        filename = f"{uuid.uuid4().hex}.{ext}"
        folder = os.path.join(current_app.config["UPLOAD_FOLDER"], subfolder)
        os.makedirs(folder, exist_ok=True)
        file_storage.save(os.path.join(folder, filename))
        return f"{subfolder}/{filename}"

    def url_for_key(self, key: str) -> str:
        return url_for("uploads.serve_upload", key=key, _external=False)

    def delete(self, key: str) -> None:
        path = os.path.join(current_app.config["UPLOAD_FOLDER"], key)
        if os.path.exists(path):
            os.remove(path)


# Single instance the rest of the app imports. Swapping storage
# backends later means changing this one line (plus adding the new
# class above) — nothing else in the codebase needs to know.
storage: StorageService = LocalStorageService()
