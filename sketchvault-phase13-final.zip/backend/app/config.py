import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


class Config:
    """Central configuration, read from environment variables.

    Nothing secret is hard-coded here — see .env.example for what
    needs to be set in a real .env file before running the app.
    """

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-not-for-production")

    # A relative sqlite:/// URI is resolved by Flask-SQLAlchemy against
    # its instance/ folder, not this file's directory — surprising the
    # first time you hit it. DATABASE_URL is only meant to be set to
    # something else (e.g. a Postgres URL) in .env; when it's unset we
    # build an explicit absolute path so "just works" really does.
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL"
    ) or f"sqlite:///{os.path.join(basedir, 'dev.db')}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "dev-jwt-secret-not-for-production")
    JWT_TOKEN_LOCATION = ["cookies"]
    JWT_ACCESS_COOKIE_NAME = "access_token"
    JWT_REFRESH_COOKIE_NAME = "refresh_token"
    JWT_COOKIE_CSRF_PROTECT = True
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=30)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)
    # In local dev over http, cookies can't be marked Secure. Flip this
    # (and JWT_COOKIE_SAMESITE) appropriately when deploying over https.
    JWT_COOKIE_SECURE = os.environ.get("FLASK_ENV") == "production"
    JWT_COOKIE_SAMESITE = "Lax"

    # Image storage — see app/services/storage.py. This just tells the
    # local storage backend where to write files; nothing else in the
    # app should reference this path directly.
    UPLOAD_FOLDER = os.path.join(basedir, os.environ.get("UPLOAD_FOLDER", "uploads"))
    MAX_CONTENT_LENGTH = int(os.environ.get("MAX_CONTENT_LENGTH", 8 * 1024 * 1024))  # 8MB
    ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

    FRONTEND_ORIGIN = os.environ.get("FRONTEND_ORIGIN", "http://localhost:5173")
