"""
Extension instances live here, separate from the app factory.

Why: models, routes, and the app factory all need to import `db`
(and `bcrypt`, `jwt`) without importing each other in a circle.
Creating the instances in their own module, unbound to any app,
and calling .init_app(app) inside create_app() is the standard
Flask pattern that avoids circular imports.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
from flask_cors import CORS

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()
bcrypt = Bcrypt()
cors = CORS()
