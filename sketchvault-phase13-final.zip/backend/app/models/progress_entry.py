from datetime import datetime
from app.extensions import db


class ProgressEntry(db.Model):
    __tablename__ = "progress_entries"

    id = db.Column(db.Integer, primary_key=True)
    artwork_id = db.Column(db.Integer, db.ForeignKey("artworks.id"), nullable=False, index=True)

    image = db.Column(db.String(255), nullable=False)  # storage key
    stage = db.Column(db.String(120), nullable=False)
    progress = db.Column(db.Integer, nullable=False)  # 0-100
    note = db.Column(db.Text, nullable=True)

    # Focal-point crop — normalised 0.0–1.0 relative to the full image.
    # When the user drags the crop box we store the centre of the box
    # (crop_cx, crop_cy) and the box dimensions (crop_w, crop_h).
    # The frontend converts these to CSS object-position / background-position
    # so the face/focal area shows correctly in gallery thumbnails and the
    # detail header without re-encoding the file.  All four default to None
    # (no crop chosen), in which case the frontend falls back to centre (50 50).
    crop_cx = db.Column(db.Float, nullable=True)   # centre-x  0.0–1.0
    crop_cy = db.Column(db.Float, nullable=True)   # centre-y  0.0–1.0
    crop_w  = db.Column(db.Float, nullable=True)   # box width  0.0–1.0
    crop_h  = db.Column(db.Float, nullable=True)   # box height 0.0–1.0

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    artwork = db.relationship("Artwork", back_populates="progress_entries")

    @property
    def crop(self):
        """Return crop dict if set, else None."""
        if self.crop_cx is not None:
            return {
                "cx": self.crop_cx,
                "cy": self.crop_cy,
                "w":  self.crop_w,
                "h":  self.crop_h,
            }
        return None

    def to_dict(self):
        from app.services.storage import storage
        return {
            "id": self.id,
            "artwork_id": self.artwork_id,
            "image_url": storage.url_for_key(self.image),
            "crop": self.crop,
            "stage": self.stage,
            "progress": self.progress,
            "note": self.note,
            "created_at": self.created_at.isoformat(),
        }
