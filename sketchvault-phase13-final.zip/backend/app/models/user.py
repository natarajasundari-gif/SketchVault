from datetime import datetime
from app.extensions import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    avatar = db.Column(db.String(255), nullable=True)  # storage key for profile picture
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    artworks = db.relationship(
        "Artwork", back_populates="user", cascade="all, delete-orphan"
    )

    def to_dict(self):
        from app.services.storage import storage
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "avatar_url": storage.url_for_key(self.avatar) if self.avatar else None,
            "created_at": self.created_at.isoformat(),
        }
