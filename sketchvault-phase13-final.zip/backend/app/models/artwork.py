from datetime import datetime
from app.extensions import db

artwork_tags = db.Table(
    "artwork_tags",
    db.Column("artwork_id", db.Integer, db.ForeignKey("artworks.id"), primary_key=True),
    db.Column("tag_id", db.Integer, db.ForeignKey("tags.id"), primary_key=True),
)


class Artwork(db.Model):
    __tablename__ = "artworks"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    cover_image = db.Column(db.String(255), nullable=True)  # storage key, not a raw path
    medium = db.Column(db.String(80), nullable=False)
    category = db.Column(db.String(80), nullable=False)
    status = db.Column(db.String(80), nullable=False, default="Sketching")
    progress = db.Column(db.Integer, nullable=False, default=0)  # 0-100, kept in sync
    # with the most recent progress entry — see services/progress_service.py

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    user = db.relationship("User", back_populates="artworks")
    tags = db.relationship("Tag", secondary=artwork_tags, back_populates="artworks")
    progress_entries = db.relationship(
        "ProgressEntry",
        back_populates="artwork",
        cascade="all, delete-orphan",
        order_by="ProgressEntry.created_at",
    )

    def to_dict(self, include_entries=False):
        from app.services.storage import storage  # local import avoids a circular import at module load

        # Cover image priority:
        #   1. Explicit cover the user uploaded (manual override)
        #   2. Most recent progress entry image (automatic fallback)
        #   3. None (frontend shows the placeholder icon)
        cover_url = None
        cover_crop = None
        if self.cover_image:
            cover_url = storage.url_for_key(self.cover_image)
        elif self.progress_entries:
            latest = max(self.progress_entries, key=lambda e: e.created_at)
            cover_url = storage.url_for_key(latest.image)
            cover_crop = latest.crop

        data = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "cover_image_url": cover_url,
            "cover_crop": cover_crop,   # focal-point crop for the cover thumbnail
            "medium": self.medium,
            "category": self.category,
            "status": self.status,
            "progress": self.progress,
            "tags": [t.name for t in self.tags],
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
        if include_entries:
            data["progress_entries"] = [e.to_dict() for e in self.progress_entries]
        return data
