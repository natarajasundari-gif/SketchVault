from app.extensions import db
from app.models.artwork import artwork_tags


class Tag(db.Model):
    __tablename__ = "tags"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), nullable=False, unique=True, index=True)

    artworks = db.relationship("Artwork", secondary=artwork_tags, back_populates="tags")

    def to_dict(self):
        return {"id": self.id, "name": self.name}
