# SketchVault — private art progress journal

A private workspace for artists to document how each artwork evolves,
from first sketch to finished piece. Built in phases; this covers
**Phase 1 (architecture)**, **Phase 2 (project foundation)**,
**Phase 3 (authentication)**, and **Phase 4 (artwork management)**.

## What exists so far

- **Backend**: Flask app factory, config, all four models
  (`User`, `Artwork`, `Tag`, `ProgressEntry`), a swappable image
  storage service, upload validation (real image-sniffing via
  Pillow, not just extension-checking), and an ownership-check
  decorator. **Authentication is fully implemented**: register,
  login, logout, session check, silent token refresh, and a
  forgot/reset-password flow. **Artwork management is fully
  implemented**: create/list/get/update/delete, each with real
  cover-image upload, tag reuse (no duplicate tags across artworks),
  search by title/description, filtering by medium/category/
  completion, and four sort orders. Progress-entry and user-profile
  routes are still stubbed (`501`) until Phases 5 and 7.
- **Frontend**: Vite + React + TypeScript. Design tokens, theme
  system, and the responsive app shell from Phase 2; real Login,
  Register, Forgot/Reset Password forms and route guards from
  Phase 3; and now a real **Gallery** (search, filter, sort, grid,
  meaningful empty states), **Artwork Form** (shared between create
  and edit, with image upload and a live progress slider),
  **Artwork Detail** page (header, edit/delete with a confirmation
  dialog), and a **Dashboard** wired to real stats and recent-work
  shelves.

Progress entries (the "Artwork Journey" timeline) are still a
placeholder on the artwork detail page — that's Phase 5.

## Verified this phase

Tested against a live server, not just assumptions:
- Full artwork CRUD round-trip (create → list → get → update →
  search → filter → sort → delete)
- Real image upload + retrieval, and rejection of a fake image
  (a text file renamed to `.jpg`) via Pillow's real image-sniffing
- Cross-user ownership isolation: a second user gets a clean 403
  attempting to view, edit, or delete another user's artwork by ID,
  and never sees it in their own list

## Running it locally

### Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
flask --app run db init && flask --app run db migrate -m "initial" && flask --app run db upgrade
python run.py
```

The API runs on `http://localhost:5000`. `GET /api/health/` should
return `{"status": "ok", "service": "sketchvault-api"}`.

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

The app runs on `http://localhost:5173`.

## Environment variables (backend/.env)

| Variable | Purpose |
|---|---|
| `SECRET_KEY` | Flask session signing |
| `JWT_SECRET_KEY` | Auth token signing |
| `DATABASE_URL` | SQLAlchemy connection string (SQLite by default) |
| `UPLOAD_FOLDER` | Where locally-stored images are written |
| `MAX_CONTENT_LENGTH` | Max upload size in bytes (default 8MB) |
| `FRONTEND_ORIGIN` | Allowed CORS origin for the React app |

## Architectural decisions worth knowing

- **Cookie-based JWT auth, not localStorage.** Tokens live in
  httpOnly cookies so they can't be read by injected/XSS'd JS. This
  is why CORS is configured with `supports_credentials=True` and a
  specific origin rather than `*`.
- **Image storage is an interface, not a filesystem call.** Every
  route saves/serves images through `app/services/storage.py`'s
  `storage` instance, and artwork records only ever store a storage
  *key* — the full URL is computed at serialization time. Moving to
  S3 or another provider later means writing one new class, not
  touching route or frontend code.
- **Ownership checks live in one decorator.** `require_artwork_owner`
  loads the artwork and checks `user_id` against the JWT identity
  before any artwork/progress route body runs.
- **Tags are normalized, not free text per artwork.** A shared `Tag`
  table plus a join table means "portrait" typed on two different
  artworks is the same tag row — filtering the gallery by tag is a
  simple join, and tags don't fragment by casing/whitespace.
- **CSS Modules + hand-written tokens, no UI kit.** Chosen so the
  visual identity (warm paper background, graphite/brass palette,
  Fraunces + Inter type pairing) isn't fighting a utility framework's
  defaults, and so the codebase stays readable without extra
  abstraction layers.

## Known limitations at this stage

- The "Artwork Journey" timeline is a placeholder on the artwork
  detail page — recording and viewing progress entries is Phase 5.
- Dashboard's fourth stat ("Progress entries recorded") is a visible
  placeholder for the same reason.
- "Forgot password" returns the reset link directly in the API
  response rather than emailing it, since no email provider is
  configured yet.
- Access tokens last 30 minutes; the frontend transparently retries
  once via the refresh cookie on a 401, so normal use shouldn't hit
  a forced logout, but there's no proactive background refresh timer.

## Next up

**Phase 5: progress tracking** — add progress, image upload per
entry, the progress timeline UI, editing/deleting entries, and
keeping an artwork's overall progress/status in sync with its most
recent entry.
