// In development, Vite proxies /api/* to Flask (see vite.config.ts), so we
// use a relative path. In production the same relative path works because
// Flask serves the built frontend from the same origin.
// VITE_API_BASE_URL can still override this for unusual setups.
const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "/api";

export class ApiError extends Error {
  status: number;
  fields?: Record<string, string>;

  constructor(message: string, status: number, fields?: Record<string, string>) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

let refreshPromise: Promise<boolean> | null = null;

/** Tries once to silently renew the access token using the refresh
 * cookie. Concurrent 401s share one in-flight refresh instead of
 * each firing their own. */
function refreshAccessToken(): Promise<boolean> {
  if (!refreshPromise) {
    refreshPromise = fetch(`${API_BASE}/auth/refresh`, {
      method: "POST",
      credentials: "include",
      headers: {
        "X-CSRF-TOKEN": getCookie("csrf_refresh_token") ?? "",
      },
    })
      .then((res) => res.ok)
      .finally(() => {
        refreshPromise = null;
      });
  }
  return refreshPromise;
}

interface RequestOptions extends RequestInit {
  _retried?: boolean;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const method = (options.method ?? "GET").toUpperCase();
  const headers = new Headers(options.headers);

  if (options.body && !headers.has("Content-Type") && !(options.body instanceof FormData)) {
    // FormData sets its own multipart boundary — letting the browser
    // handle that header is required, so JSON bodies are the only
    // ones that get Content-Type set here.
    headers.set("Content-Type", "application/json");
  }
  if (["POST", "PUT", "PATCH", "DELETE"].includes(method) && path !== "/auth/refresh") {
    const csrfToken = getCookie("csrf_access_token");
    if (csrfToken) headers.set("X-CSRF-TOKEN", csrfToken);
  }

  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
      credentials: "include",
    });
  } catch (networkErr) {
    // Server is down or unreachable — throw a recognisable ApiError
    // so every form can show a helpful message instead of a raw TypeError.
    throw new ApiError(
      "Cannot reach the server. Make sure the Flask backend is running on port 5000.",
      0
    );
  }

  // Access token expired mid-session: try one silent refresh, then
  // replay the original request, before surfacing an error.
  if (res.status === 401 && !options._retried && path !== "/auth/refresh") {
    const refreshed = await refreshAccessToken();
    if (refreshed) {
      return request<T>(path, { ...options, _retried: true });
    }
  }

  const data = await res.json().catch(() => null);

  if (!res.ok) {
    throw new ApiError(data?.error ?? "Something went wrong", res.status, data?.fields);
  }

  return data as T;
}

export const api = {
  get: <T,>(path: string) => request<T>(path),
  post: <T,>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  put: <T,>(path: string, body?: unknown) =>
    request<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined }),
  postForm: <T,>(path: string, form: FormData) => request<T>(path, { method: "POST", body: form }),
  putForm: <T,>(path: string, form: FormData) => request<T>(path, { method: "PUT", body: form }),
  delete: <T,>(path: string, body?: unknown) =>
    request<T>(path, { method: "DELETE", ...(body ? { body: JSON.stringify(body) } : {}) }),
};
