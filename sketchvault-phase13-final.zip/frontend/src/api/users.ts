import { api } from "./client";
import type { AuthUser } from "./auth";

export const usersApi = {
  getProfile: () =>
    api.get<{ user: AuthUser }>("/users/me"),

  updateProfile: (data: { name?: string; email?: string }) =>
    api.put<{ user: AuthUser }>("/users/me", data),

  changePassword: (data: { current_password: string; new_password: string }) =>
    api.put<{ message: string }>("/users/me/password", data),

  deleteAccount: (data: { password: string }) =>
    api.delete<{ message: string }>("/users/me", data),

  uploadAvatar: (file: File) => {
    const form = new FormData();
    form.set("avatar", file);
    return api.postForm<{ user: AuthUser }>("/users/me/avatar", form);
  },

  removeAvatar: () =>
    api.delete<{ user: AuthUser }>("/users/me/avatar"),
};
