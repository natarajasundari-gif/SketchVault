import { api } from "./client";
import type { CropRect } from "../components/ui/CropPicker";

export interface ProgressEntry {
  id: number;
  artwork_id: number;
  image_url: string;
  crop: CropRect | null;
  stage: string;
  progress: number;
  note: string | null;
  created_at: string;
}

export const progressApi = {
  list: (artworkId: number) =>
    api.get<{ entries: ProgressEntry[] }>(`/artworks/${artworkId}/progress`),

  /** Pass a pre-built FormData (includes image + crop fields). */
  addRaw: (artworkId: number, form: FormData) =>
    api.postForm<{ entry: ProgressEntry; artwork: { progress: number; status: string; cover_image_url: string | null; cover_crop: CropRect | null } }>(
      `/artworks/${artworkId}/progress`, form
    ),

  updateRaw: (artworkId: number, entryId: number, form: FormData) =>
    api.putForm<{ entry: ProgressEntry; artwork: { progress: number; status: string; cover_image_url: string | null; cover_crop: CropRect | null } }>(
      `/artworks/${artworkId}/progress/${entryId}`, form
    ),

  remove: (artworkId: number, entryId: number) =>
    api.delete<{ message: string; artwork: { progress: number; status: string } }>(
      `/artworks/${artworkId}/progress/${entryId}`
    ),
};
