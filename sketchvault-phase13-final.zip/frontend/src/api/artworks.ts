import { api } from "./client";

export interface CropRect {
  cx: number;
  cy: number;
  w: number;
  h: number;
}

export interface Artwork {
  id: number;
  title: string;
  description: string | null;
  cover_image_url: string | null;
  cover_crop: CropRect | null;
  medium: string;
  category: string;
  status: string;
  progress: number;
  tags: string[];
  created_at: string;
  updated_at: string;
  progress_entries?: ProgressEntry[];
}

export interface ProgressEntry {
  id: number;
  artwork_id: number;
  image: string;
  stage: string;
  progress: number;
  note: string | null;
  created_at: string;
}

export interface ArtworkListFilters {
  q?: string;
  medium?: string;
  category?: string;
  status?: string;
  tag?: string;
  completed?: "true" | "false";
  sort?: "recent_updated" | "recent_created" | "alphabetical" | "progress";
}

export interface ArtworkFormValues {
  title: string;
  description?: string;
  medium: string;
  category: string;
  status: string;
  progress: number;
  tags: string[];
  coverImage?: File | null;
}

function toFormData(values: Partial<ArtworkFormValues>): FormData {
  const form = new FormData();
  if (values.title !== undefined) form.set("title", values.title);
  if (values.description !== undefined) form.set("description", values.description ?? "");
  if (values.medium !== undefined) form.set("medium", values.medium);
  if (values.category !== undefined) form.set("category", values.category);
  if (values.status !== undefined) form.set("status", values.status);
  if (values.progress !== undefined) form.set("progress", String(values.progress));
  if (values.tags !== undefined) form.set("tags", values.tags.join(","));
  if (values.coverImage) form.set("cover_image", values.coverImage);
  return form;
}

function buildQuery(filters: ArtworkListFilters = {}): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    if (value) params.set(key, value);
  }
  const qs = params.toString();
  return qs ? `?${qs}` : "";
}

export const artworksApi = {
  list: (filters?: ArtworkListFilters) =>
    api.get<{ artworks: Artwork[]; total_entries: number }>(`/artworks/${buildQuery(filters)}`),

  get: (id: number) => api.get<{ artwork: Artwork }>(`/artworks/${id}`),

  create: (values: ArtworkFormValues) =>
    api.postForm<{ artwork: Artwork }>("/artworks/", toFormData(values)),

  update: (id: number, values: Partial<ArtworkFormValues>) =>
    api.putForm<{ artwork: Artwork }>(`/artworks/${id}`, toFormData(values)),

  remove: (id: number) => api.delete<{ message: string }>(`/artworks/${id}`),
};

export const tagsApi = {
  list: () => api.get<{ tags: { id: number; name: string }[] }>("/tags/"),
};
