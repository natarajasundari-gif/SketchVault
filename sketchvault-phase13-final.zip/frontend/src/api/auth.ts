import { api } from "./client";

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  avatar_url: string | null;
  created_at: string;
}

interface UserResponse {
  user: AuthUser;
}

export const authApi = {
  register: (name: string, email: string, password: string) =>
    api.post<UserResponse>("/auth/register", { name, email, password }),

  login: (email: string, password: string) =>
    api.post<UserResponse>("/auth/login", { email, password }),

  logout: () => api.post<{ message: string }>("/auth/logout"),

  me: () => api.get<UserResponse>("/auth/me"),

  forgotPassword: (email: string) =>
    api.post<{ message: string; dev_reset_url?: string }>("/auth/forgot-password", { email }),

  resetPassword: (token: string, password: string) =>
    api.post<{ message: string }>("/auth/reset-password", { token, password }),
};
