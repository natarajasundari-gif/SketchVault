import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus } from "lucide-react";

import { artworksApi, type ArtworkListFilters } from "../../api/artworks";
import { MEDIUMS, CATEGORIES, SORT_OPTIONS } from "../../constants/artwork";
import { ArtworkCard } from "../../components/artwork/ArtworkCard";
import { EmptyState } from "../../components/feedback/EmptyState";
import { Button } from "../../components/ui/Button";
import styles from "./Gallery.module.css";

export function Gallery() {
  const [searchInput, setSearchInput] = useState("");
  const [filters, setFilters] = useState<ArtworkListFilters>({ sort: "recent_updated" });

  // Debounce search-as-you-type so every keystroke doesn't fire a request.
  useEffect(() => {
    const handle = setTimeout(() => {
      setFilters((prev) => ({ ...prev, q: searchInput || undefined }));
    }, 300);
    return () => clearTimeout(handle);
  }, [searchInput]);

  const { data, isLoading, isError } = useQuery({
    queryKey: ["artworks", filters],
    queryFn: () => artworksApi.list(filters),
  });

  const artworks = data?.artworks ?? [];
  const hasActiveFilters = !!(filters.q || filters.medium || filters.category || filters.status);

  return (
    <div>
      <div className={styles.header}>
        <h1>All artworks</h1>
        <Link to="/app/artworks/new">
          <Button icon={<Plus size={16} strokeWidth={2} />}>New artwork</Button>
        </Link>
      </div>

      <div className={styles.controls}>
        <div className={styles.searchWrap}>
          <Search size={16} strokeWidth={2} className={styles.searchIcon} />
          <input
            className={styles.searchInput}
            placeholder="Search by title or description…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            aria-label="Search artworks"
          />
        </div>

        <select
          className={styles.selectFilter}
          value={filters.medium ?? ""}
          onChange={(e) => setFilters((prev) => ({ ...prev, medium: e.target.value || undefined }))}
          aria-label="Filter by medium"
        >
          <option value="">All mediums</option>
          {MEDIUMS.map((m) => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>

        <select
          className={styles.selectFilter}
          value={filters.category ?? ""}
          onChange={(e) => setFilters((prev) => ({ ...prev, category: e.target.value || undefined }))}
          aria-label="Filter by category"
        >
          <option value="">All categories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        <select
          className={styles.selectFilter}
          value={filters.completed ?? ""}
          onChange={(e) =>
            setFilters((prev) => ({
              ...prev,
              completed: (e.target.value || undefined) as "true" | "false" | undefined,
            }))
          }
          aria-label="Filter by completion"
        >
          <option value="">All progress</option>
          <option value="false">In progress</option>
          <option value="true">Completed</option>
        </select>

        <select
          className={styles.selectFilter}
          value={filters.sort ?? "recent_updated"}
          onChange={(e) => setFilters((prev) => ({ ...prev, sort: e.target.value as ArtworkListFilters["sort"] }))}
          aria-label="Sort artworks"
        >
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>

      {isLoading && (
        <div className={styles.grid}>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className={styles.skeleton} />
          ))}
        </div>
      )}

      {isError && (
        <EmptyState
          title="Couldn't load your artworks"
          message="Something went wrong reaching the studio. Please try again."
        />
      )}

      {!isLoading && !isError && artworks.length === 0 && !hasActiveFilters && (
        <EmptyState
          title="Your studio is empty."
          message="Every finished artwork starts with a blank space."
          action={
            <Link to="/app/artworks/new">
              <Button>Create your first artwork</Button>
            </Link>
          }
        />
      )}

      {!isLoading && !isError && artworks.length === 0 && hasActiveFilters && (
        <EmptyState
          title="No artworks match"
          message="Try a different search term or clear your filters."
        />
      )}

      {!isLoading && !isError && artworks.length > 0 && (
        <div className={styles.grid}>
          {artworks.map((artwork) => (
            <ArtworkCard key={artwork.id} artwork={artwork} />
          ))}
        </div>
      )}
    </div>
  );
}
