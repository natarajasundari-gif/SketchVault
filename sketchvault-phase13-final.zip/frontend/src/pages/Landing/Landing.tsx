import { Link } from "react-router-dom";
import { Button } from "../../components/ui/Button";
import styles from "./Landing.module.css";

export function Landing() {
  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <span className={styles.brand}>SketchVault</span>
        <div className={styles.headerActions}>
          <Link to="/login" className={styles.textLink}>Log in</Link>
          <Link to="/register">
            <Button size="sm">Get started</Button>
          </Link>
        </div>
      </header>

      <main className={styles.hero}>
        <h1>Your art has a story. Keep every chapter.</h1>
        <p className={styles.sub}>
          A private workspace for artists to document how each piece evolves
          — from the first sketch to the final stroke.
        </p>
        <Link to="/register">
          <Button size="lg">Start your first artwork</Button>
        </Link>
      </main>
    </div>
  );
}
