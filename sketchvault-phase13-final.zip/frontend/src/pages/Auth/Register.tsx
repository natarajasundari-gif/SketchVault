import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { useAuth } from "../../context/AuthContext";
import { ApiError } from "../../api/client";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { FormError } from "../../components/feedback/FormError";
import styles from "./Auth.module.css";

const schema = z
  .object({
    name: z.string().min(1, "Name is required"),
    email: z.string().min(1, "Email is required").email("Enter a valid email address"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string().min(1, "Please confirm your password"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });
type FormValues = z.infer<typeof schema>;

export function Register() {
  const { register: registerUser } = useAuth();
  const navigate = useNavigate();
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    setFormError(null);
    try {
      await registerUser(values.name, values.email, values.password);
      navigate("/app", { replace: true });
    } catch (err) {
      if (err instanceof ApiError && err.fields) {
        for (const [field, message] of Object.entries(err.fields)) {
          if (field === "name" || field === "email" || field === "password") {
            setError(field, { message });
          }
        }
        if (err.message) setFormError(err.message);
      } else if (err instanceof ApiError) {
        if (err.status === 0) {
          setFormError("Cannot reach the server. Make sure the Flask backend is running on port 5000.");
        } else if (err.status === 409) {
          setFormError("An account with this email already exists. Try logging in instead.");
        } else {
          setFormError(`Server error (${err.status}): ${err.message}`);
        }
      } else {
        setFormError(`Unexpected error: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.card}>
        <Link to="/" className={styles.brand}>SketchVault</Link>
        <h1>Create your studio</h1>
        <p className={styles.subtitle}>A private space to track every artwork's journey.</p>

        <FormError message={formError} />

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <Input label="Name" autoComplete="name" error={errors.name?.message} {...register("name")} />
          <Input
            label="Email"
            type="email"
            autoComplete="email"
            error={errors.email?.message}
            {...register("email")}
          />
          <Input
            label="Password"
            type="password"
            autoComplete="new-password"
            error={errors.password?.message}
            {...register("password")}
          />
          <Input
            label="Confirm password"
            type="password"
            autoComplete="new-password"
            error={errors.confirmPassword?.message}
            {...register("confirmPassword")}
          />
          <Button type="submit" fullWidth disabled={isSubmitting}>
            {isSubmitting ? "Creating your studio…" : "Create account"}
          </Button>
        </form>

        <p className={styles.footerNote}>
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}
