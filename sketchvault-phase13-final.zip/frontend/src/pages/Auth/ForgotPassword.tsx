import { useState } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { authApi } from "../../api/auth";
import { ApiError } from "../../api/client";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { FormError } from "../../components/feedback/FormError";
import styles from "./Auth.module.css";

const schema = z.object({
  email: z.string().min(1, "Email is required").email("Enter a valid email address"),
});
type FormValues = z.infer<typeof schema>;

export function ForgotPassword() {
  const [formError, setFormError] = useState<string | null>(null);
  const [devResetUrl, setDevResetUrl] = useState<string | null>(null);
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    setFormError(null);
    try {
      const res = await authApi.forgotPassword(values.email);
      setSubmittedMessage(res.message);
      setDevResetUrl(res.dev_reset_url ?? null);
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : "Something went wrong. Please try again.");
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.card}>
        <Link to="/" className={styles.brand}>SketchVault</Link>
        <h1>Reset your password</h1>
        <p className={styles.subtitle}>We'll send you a link to get back in.</p>

        <FormError message={formError} />

        {submittedMessage ? (
          <div className={styles.successBanner}>
            {submittedMessage}
            {devResetUrl && (
              <span className={styles.devHint}>
                No email delivery is configured yet for local development —
                use this link directly: <Link to={devResetUrl}>{devResetUrl}</Link>
              </span>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <Input
              label="Email"
              type="email"
              autoComplete="email"
              error={errors.email?.message}
              {...register("email")}
            />
            <Button type="submit" fullWidth disabled={isSubmitting}>
              {isSubmitting ? "Sending…" : "Send reset link"}
            </Button>
          </form>
        )}

        <p className={styles.footerNote}>
          <Link to="/login">Back to log in</Link>
        </p>
      </div>
    </div>
  );
}
