import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ImageIcon, Pencil, Trash2, Plus } from "lucide-react";

import { artworksApi } from "../../api/artworks";
import { progressApi, type ProgressEntry } from "../../api/progress";
import { Button } from "../../components/ui/Button";
import { ConfirmDialog } from "../../components/ui/ConfirmDialog";
import { EmptyState } from "../../components/feedback/EmptyState";
import { Timeline } from "../../components/artwork/Timeline";
import { ProgressModal } from "../../components/artwork/ProgressModal";
import { useToast } from "../../components/ui/Toast";
import { cropToObjectPosition } from "../../utils/cropToPosition";
import styles from "./ArtworkDetail.module.css";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString(undefined, {
    month: "long", day: "numeric", year: "numeric",
  });
}

export function ArtworkDetail() {
  const { artworkId } = useParams();
  const id = Number(artworkId);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { showToast } = useToast();

  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [editingEntry, setEditingEntry] = useState<ProgressEntry | undefined>();
  const [deletingEntry, setDeletingEntry] = useState<ProgressEntry | undefined>();

  const { data: artworkData, isLoading, isError } = useQuery({
    queryKey: ["artwork", artworkId],
    queryFn: () => artworksApi.get(id),
  });

  const { data: progressData } = useQuery({
    queryKey: ["progress", id],
    queryFn: () => progressApi.list(id),
    enabled: !!artworkData,
  });

  const deleteMutation = useMutation({
    mutationFn: () => artworksApi.remove(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["artworks"] });
      showToast("Artwork deleted");
      navigate("/app/gallery", { replace: true });
    },
    onError: () => {
      showToast("Couldn't delete this artwork. Please try again.", "error");
      setConfirmingDelete(false);
    },
  });

  const deleteEntryMutation = useMutation({
    mutationFn: (entry: ProgressEntry) => progressApi.remove(id, entry.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["progress", id] });
      queryClient.invalidateQueries({ queryKey: ["artwork", artworkId] });
      queryClient.invalidateQueries({ queryKey: ["artworks"] });
      showToast("Progress entry deleted");
      setDeletingEntry(undefined);
    },
    onError: () => {
      showToast("Couldn't delete this entry. Please try again.", "error");
      setDeletingEntry(undefined);
    },
  });

  if (isLoading) return (
    <p style={{ color: "var(--color-text-muted)" }}>Loading artwork…</p>
  );

  if (isError || !artworkData?.artwork) return (
    <EmptyState
      title="Artwork not found"
      message="It may have been deleted, or the link is incorrect."
      action={<Link to="/app/gallery"><Button>Back to gallery</Button></Link>}
    />
  );

  const artwork = artworkData.artwork;
  const entries = progressData?.entries ?? [];

  return (
    <div>
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <div className={styles.header}>
        <div className={styles.coverWrap}>
          {artwork.cover_image_url ? (
            <img src={artwork.cover_image_url} alt={artwork.title} className={styles.coverImage} style={{ objectPosition: cropToObjectPosition(artwork.cover_crop) }} />
          ) : (
            <div className={styles.coverPlaceholder}>
              <ImageIcon size={40} strokeWidth={1.25} />
            </div>
          )}
        </div>

        <div className={styles.info}>
          <div className={styles.titleRow}>
            <h1>{artwork.title}</h1>
            <div className={styles.actions}>
              <Link to={`/app/artworks/${artwork.id}/edit`}>
                <Button variant="secondary" size="sm" icon={<Pencil size={14} strokeWidth={2} />}>
                  Edit
                </Button>
              </Link>
              <Button
                variant="danger"
                size="sm"
                icon={<Trash2 size={14} strokeWidth={2} />}
                onClick={() => setConfirmingDelete(true)}
              >
                Delete
              </Button>
            </div>
          </div>

          {artwork.description && (
            <p className={styles.description}>{artwork.description}</p>
          )}

          <div className={styles.metaGrid}>
            <div>
              <div className={styles.metaLabel}>Medium</div>
              <div>{artwork.medium}</div>
            </div>
            <div>
              <div className={styles.metaLabel}>Category</div>
              <div>{artwork.category}</div>
            </div>
            <div>
              <div className={styles.metaLabel}>Status</div>
              <div>{artwork.status}</div>
            </div>
            <div>
              <div className={styles.metaLabel}>Created</div>
              <div>{formatDate(artwork.created_at)}</div>
            </div>
            <div>
              <div className={styles.metaLabel}>Last updated</div>
              <div>{formatDate(artwork.updated_at)}</div>
            </div>
          </div>

          <div>
            <div className={styles.metaLabel} style={{ marginBottom: "0.4rem" }}>
              Progress — {artwork.progress}%
            </div>
            <div className={styles.progressTrack}>
              <div className={styles.progressFill} style={{ width: `${artwork.progress}%` }} />
            </div>
          </div>

          {artwork.tags.length > 0 && (
            <div className={styles.tags}>
              {artwork.tags.map((tag) => (
                <span key={tag} className={styles.tag}>{tag}</span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Artwork Journey ─────────────────────────────────────────────── */}
      <div className={styles.journeyHeader}>
        <h2>Artwork Journey</h2>
        <Button
          icon={<Plus size={15} strokeWidth={2} />}
          onClick={() => { setEditingEntry(undefined); setShowProgressModal(true); }}
        >
          Add progress
        </Button>
      </div>

      {entries.length === 0 ? (
        <EmptyState
          title="This artwork hasn't started its journey yet."
          message="Add your first progress photo to begin documenting how this piece evolves."
          action={
            <Button
              icon={<Plus size={15} strokeWidth={2} />}
              onClick={() => { setEditingEntry(undefined); setShowProgressModal(true); }}
            >
              Add first progress
            </Button>
          }
        />
      ) : (
        <Timeline
          entries={entries}
          onEdit={(entry) => { setEditingEntry(entry); setShowProgressModal(true); }}
          onDelete={setDeletingEntry}
        />
      )}

      {/* ── Modals ──────────────────────────────────────────────────────── */}
      {showProgressModal && (
        <ProgressModal
          artworkId={id}
          currentProgress={artwork.progress}
          entry={editingEntry}
          onClose={() => { setShowProgressModal(false); setEditingEntry(undefined); }}
        />
      )}

      {confirmingDelete && (
        <ConfirmDialog
          title="Delete this artwork?"
          message={`"${artwork.title}" and all its progress history will be permanently removed. This can't be undone.`}
          confirmLabel="Delete artwork"
          isConfirming={deleteMutation.isPending}
          onConfirm={() => deleteMutation.mutate()}
          onCancel={() => setConfirmingDelete(false)}
        />
      )}

      {deletingEntry && (
        <ConfirmDialog
          title="Delete this progress entry?"
          message="This image and note will be permanently removed from the journey."
          confirmLabel="Delete entry"
          isConfirming={deleteEntryMutation.isPending}
          onConfirm={() => deleteEntryMutation.mutate(deletingEntry)}
          onCancel={() => setDeletingEntry(undefined)}
        />
      )}
    </div>
  );
}
