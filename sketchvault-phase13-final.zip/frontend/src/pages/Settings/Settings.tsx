import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { LogOut, Camera } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";

import { usersApi } from "../../api/users";
import { authApi } from "../../api/auth";
import { ApiError } from "../../api/client";
import { useAuth } from "../../context/AuthContext";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { ThemeToggle } from "../../components/ui/ThemeToggle";
import { ConfirmDialog } from "../../components/ui/ConfirmDialog";
import { FormError } from "../../components/feedback/FormError";
import { useToast } from "../../components/ui/Toast";
import styles from "./Settings.module.css";

// ── Avatar section ────────────────────────────────────────────────────────────

function AvatarSection() {
  const { user, setUser } = useAuth();
  const { showToast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);

  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()
    : "?";

  const uploadMutation = useMutation({
    mutationFn: (file: File) => usersApi.uploadAvatar(file),
    onSuccess: (data) => { setUser(data.user); showToast("Profile picture updated"); },
    onError: () => showToast("Couldn't upload image. Please try again.", "error"),
  });

  const removeMutation = useMutation({
    mutationFn: () => usersApi.removeAvatar(),
    onSuccess: (data) => { setUser(data.user); showToast("Profile picture removed"); },
    onError: () => showToast("Couldn't remove image. Please try again.", "error"),
  });

  function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) uploadMutation.mutate(file);
    e.target.value = "";
  }

  return (
    <div className={styles.avatarSection}>
      <div className={styles.avatarWrap}>
        {user?.avatar_url ? (
          <img src={user.avatar_url} alt={user.name} className={styles.avatarImg} />
        ) : (
          <div className={styles.avatarInitials}>{initials}</div>
        )}
        {/* Camera overlay button */}
        <button
          className={styles.avatarEditBtn}
          onClick={() => inputRef.current?.click()}
          disabled={uploadMutation.isPending}
          aria-label="Change profile picture"
        >
          <Camera size={14} strokeWidth={2} />
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={onFileChange}
        />
      </div>

      <div className={styles.avatarInfo}>
        <div className={styles.profileName}>{user?.name}</div>
        <div className={styles.profileEmail}>{user?.email}</div>
        <div className={styles.avatarActions}>
          <button
            className={styles.editLink}
            onClick={() => inputRef.current?.click()}
            disabled={uploadMutation.isPending}
          >
            {uploadMutation.isPending ? "Uploading…" : "Change picture"}
          </button>
          {user?.avatar_url && (
            <>
              <span style={{ color: "var(--color-text-faint)" }}>·</span>
              <button
                className={`${styles.editLink} ${styles.editLinkDanger}`}
                onClick={() => removeMutation.mutate()}
                disabled={removeMutation.isPending}
              >
                {removeMutation.isPending ? "Removing…" : "Remove"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Profile edit form ─────────────────────────────────────────────────────────

const profileSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Please enter a valid email address"),
});
type ProfileValues = z.infer<typeof profileSchema>;

function ProfileForm({ onDone }: { onDone: () => void }) {
  const { user, setUser } = useAuth();
  const { showToast } = useToast();
  const [formError, setFormError] = useState<string | null>(null);

  const { register, handleSubmit, setError, formState: { errors } } = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: { name: user?.name ?? "", email: user?.email ?? "" },
  });

  const mutation = useMutation({
    mutationFn: (values: ProfileValues) => usersApi.updateProfile(values),
    onSuccess: (data) => { setUser(data.user); showToast("Profile updated"); onDone(); },
    onError: (err) => {
      if (err instanceof ApiError && err.fields) {
        for (const [field, msg] of Object.entries(err.fields)) {
          if (field === "name" || field === "email") setError(field, { message: msg });
        }
      } else {
        setFormError(err instanceof ApiError ? err.message : "Something went wrong.");
      }
    },
  });

  return (
    <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate>
      <FormError message={formError} />
      <Input label="Full name" error={errors.name?.message} {...register("name")} />
      <Input label="Email" type="email" error={errors.email?.message} {...register("email")} />
      <div className={styles.formActions}>
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? "Saving…" : "Save changes"}
        </Button>
        <Button type="button" variant="secondary" onClick={onDone}>Cancel</Button>
      </div>
    </form>
  );
}

// ── Change password form ──────────────────────────────────────────────────────

const passwordSchema = z.object({
  current_password: z.string().min(1, "Current password is required"),
  new_password: z.string().min(8, "Password must be at least 8 characters"),
  confirm_password: z.string(),
}).refine((d) => d.new_password === d.confirm_password, {
  message: "Passwords don't match",
  path: ["confirm_password"],
});
type PasswordValues = z.infer<typeof passwordSchema>;

function PasswordForm({ onDone }: { onDone: () => void }) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [formError, setFormError] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);
  const [sendingReset, setSendingReset] = useState(false);

  const { register, handleSubmit, setError, reset, formState: { errors } } = useForm<PasswordValues>({
    resolver: zodResolver(passwordSchema),
  });

  const mutation = useMutation({
    mutationFn: (values: PasswordValues) =>
      usersApi.changePassword({ current_password: values.current_password, new_password: values.new_password }),
    onSuccess: () => { showToast("Password changed"); reset(); onDone(); },
    onError: (err) => {
      if (err instanceof ApiError && err.fields) {
        for (const [field, msg] of Object.entries(err.fields)) {
          if (field === "current_password" || field === "new_password") setError(field, { message: msg });
        }
      } else {
        setFormError(err instanceof ApiError ? err.message : "Something went wrong.");
      }
    },
  });

  async function handleForgotPassword() {
    if (!user?.email) return;
    setSendingReset(true);
    try {
      await authApi.forgotPassword(user.email);
      setResetSent(true);
    } catch {
      setFormError("Couldn't send reset link. Please try again.");
    } finally {
      setSendingReset(false);
    }
  }

  if (resetSent) {
    return (
      <div className={styles.resetSentBox}>
        <p>A password reset link has been sent to <strong>{user?.email}</strong>.</p>
        <p style={{ marginTop: "var(--space-2)", fontSize: "var(--fs-sm)", color: "var(--color-text-muted)" }}>
          Check your inbox and follow the link to set a new password. Then log back in.
        </p>
        <Button type="button" variant="secondary" onClick={onDone} style={{ marginTop: "var(--space-3)" }}>
          Done
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate>
      <FormError message={formError} />
      <Input
        label="Current password"
        type="password"
        error={errors.current_password?.message}
        {...register("current_password")}
      />
      {/* Forgot password link — right below the current password field */}
      <div style={{ marginTop: "-0.5rem", marginBottom: "var(--space-4)" }}>
        <button
          type="button"
          className={styles.editLink}
          onClick={handleForgotPassword}
          disabled={sendingReset}
        >
          {sendingReset ? "Sending link…" : "Forgot your current password?"}
        </button>
      </div>
      <Input
        label="New password"
        type="password"
        error={errors.new_password?.message}
        {...register("new_password")}
      />
      <Input
        label="Confirm new password"
        type="password"
        error={errors.confirm_password?.message}
        {...register("confirm_password")}
      />
      <div className={styles.formActions}>
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? "Updating…" : "Update password"}
        </Button>
        <Button type="button" variant="secondary" onClick={onDone}>Cancel</Button>
      </div>
    </form>
  );
}

// ── Delete account ────────────────────────────────────────────────────────────

const deleteSchema = z.object({
  password: z.string().min(1, "Password is required to confirm deletion"),
});
type DeleteValues = z.infer<typeof deleteSchema>;

function DeleteAccountForm({ onCancel }: { onCancel: () => void }) {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [formError, setFormError] = useState<string | null>(null);

  const { register, handleSubmit, setError, formState: { errors } } = useForm<DeleteValues>({
    resolver: zodResolver(deleteSchema),
  });

  const mutation = useMutation({
    mutationFn: (values: DeleteValues) => usersApi.deleteAccount({ password: values.password }),
    onSuccess: async () => {
      await logout();
      showToast("Account deleted");
      navigate("/", { replace: true });
    },
    onError: (err) => {
      if (err instanceof ApiError && err.fields?.password) {
        setError("password", { message: err.fields.password });
      } else {
        setFormError(err instanceof ApiError ? err.message : "Something went wrong.");
      }
    },
  });

  return (
    <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate>
      <FormError message={formError} />
      <Input
        label="Enter your password to confirm"
        type="password"
        error={errors.password?.message}
        {...register("password")}
      />
      <div className={styles.formActions}>
        <Button type="submit" variant="danger" disabled={mutation.isPending}>
          {mutation.isPending ? "Deleting…" : "Delete my account"}
        </Button>
        <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}

// ── Main Settings page ────────────────────────────────────────────────────────

export function Settings() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [editingProfile, setEditingProfile] = useState(false);
  const [editingPassword, setEditingPassword] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const [confirmingLogout, setConfirmingLogout] = useState(false);

  const handleLogout = async () => {
    await logout();
    queryClient.clear();
    navigate("/", { replace: true });
  };

  return (
    <div className={styles.page}>
      <h1 style={{ marginBottom: "var(--space-2)" }}>Settings</h1>

      {/* ── Avatar + Profile ── */}
      <section className={styles.section}>
        <div className={styles.sectionTitle}>Profile</div>
        <AvatarSection />
        {editingProfile ? (
          <ProfileForm onDone={() => setEditingProfile(false)} />
        ) : (
          <button className={styles.editLink} onClick={() => setEditingProfile(true)}>
            Edit name or email
          </button>
        )}
      </section>

      {/* ── Password ── */}
      <section className={styles.section}>
        <div className={styles.sectionTitle}>Password</div>
        {editingPassword ? (
          <PasswordForm onDone={() => setEditingPassword(false)} />
        ) : (
          <button className={styles.editLink} onClick={() => setEditingPassword(true)}>
            Change password
          </button>
        )}
      </section>

      {/* ── Appearance ── */}
      <section className={styles.section}>
        <div className={styles.sectionTitle}>Appearance</div>
        <div className={styles.appearanceRow}>
          <span className={styles.appearanceLabel}>Theme</span>
          <ThemeToggle />
        </div>
      </section>

      {/* ── Session ── */}
      <section className={styles.section}>
        <div className={styles.sectionTitle}>Session</div>
        <div className={styles.logoutRow}>
          <Button
            variant="secondary"
            icon={<LogOut size={16} strokeWidth={1.75} />}
            onClick={() => setConfirmingLogout(true)}
          >
            Log out
          </Button>
        </div>
      </section>

      {/* ── Danger zone ── */}
      <section className={styles.section}>
        <div className={styles.sectionTitle}>Danger zone</div>
        <div className={styles.dangerZone}>
          <div className={styles.dangerTitle}>Delete account</div>
          <p className={styles.dangerText}>
            Permanently removes your account, all your artworks, and every progress entry.
            This cannot be undone.
          </p>
          {deletingAccount ? (
            <DeleteAccountForm onCancel={() => setDeletingAccount(false)} />
          ) : (
            <Button variant="danger" onClick={() => setDeletingAccount(true)}>
              Delete my account
            </Button>
          )}
        </div>
      </section>

      {confirmingLogout && (
        <ConfirmDialog
          title="Log out?"
          message="You'll need to sign in again to access your artworks."
          confirmLabel="Log out"
          onConfirm={handleLogout}
          onCancel={() => setConfirmingLogout(false)}
        />
      )}
    </div>
  );
}
