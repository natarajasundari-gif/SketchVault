import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";

import { artworksApi } from "../../api/artworks";
import { useAuth } from "../../context/AuthContext";
import { ArtworkCard } from "../../components/artwork/ArtworkCard";
import { EmptyState } from "../../components/feedback/EmptyState";
import { Button } from "../../components/ui/Button";
import styles from "./Dashboard.module.css";

export function Dashboard() {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ["artworks", { sort: "recent_updated" }],
    queryFn: () => artworksApi.list({ sort: "recent_updated" }),
  });

  const artworks = data?.artworks ?? [];
  const totalEntries = data?.total_entries ?? 0;
  const inProgress = artworks.filter((a) => a.progress < 100);
  const completed = artworks.filter((a) => a.progress >= 100);
  const recentlyUpdated = artworks.slice(0, 4);
  const recentlyCompleted = completed.slice(0, 4);

  const displayName = user?.name ?? "";

  if (!isLoading && artworks.length === 0) {
    return (
      <div>
        <div className={styles.greeting}>
          <h1>{displayName ? `Welcome, ${displayName}` : "Your studio"}</h1>
        </div>
        <EmptyState
          title="Your studio is empty."
          message="Every finished artwork starts with a blank space."
          action={
            <Link to="/app/artworks/new">
              <Button>Create your first artwork</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div>
      <div className={styles.greeting}>
        <h1>{displayName ? `Welcome back, ${displayName}` : "Your studio"}</h1>
        <p>
          {inProgress.length > 0
            ? `${inProgress.length} artwork${inProgress.length === 1 ? "" : "s"} currently in progress. Continue where you left off.`
            : "Ready to start something new?"}
        </p>
      </div>

      <div className={styles.statsRow}>
        <div className={styles.statCard}>
          <div className={styles.statValue}>{artworks.length}</div>
          <div className={styles.statLabel}>Total artworks</div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statValue}>{inProgress.length}</div>
          <div className={styles.statLabel}>In progress</div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statValue}>{completed.length}</div>
          <div className={styles.statLabel}>Completed</div>
        </div>
        <div className={styles.statCard}>
          <div className={styles.statValue}>{totalEntries}</div>
          <div className={styles.statLabel}>Progress entries recorded</div>
        </div>
      </div>

      {!isLoading && recentlyUpdated.length > 0 && (
        <div className={styles.section}>
          <div className={styles.sectionHeading}>
            <h2>Continue working</h2>
            <Link to="/app/gallery">View all</Link>
          </div>
          <div className={styles.grid}>
            {recentlyUpdated.map((artwork) => (
              <ArtworkCard key={artwork.id} artwork={artwork} />
            ))}
          </div>
        </div>
      )}

      {!isLoading && recentlyCompleted.length > 0 && (
        <div className={styles.section}>
          <div className={styles.sectionHeading}>
            <h2>Recently completed</h2>
          </div>
          <div className={styles.grid}>
            {recentlyCompleted.map((artwork) => (
              <ArtworkCard key={artwork.id} artwork={artwork} />
            ))}
          </div>
        </div>
      )}

      <Link to="/app/artworks/new">
        <Button icon={<Plus size={16} strokeWidth={2} />}>New artwork</Button>
      </Link>
    </div>
  );
}
