import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { artworksApi } from "../../api/artworks";
import { ApiError } from "../../api/client";
import { MEDIUMS, CATEGORIES } from "../../constants/artwork";
import { Input } from "../../components/ui/Input";
import { Select } from "../../components/ui/Select";
import { Textarea } from "../../components/ui/Textarea";
import { Button } from "../../components/ui/Button";
import { FormError } from "../../components/feedback/FormError";
import { useToast } from "../../components/ui/Toast";
import styles from "./ArtworkForm.module.css";

const schema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  medium: z.string().min(1, "Choose a medium"),
  category: z.string().min(1, "Choose a category"),
  tags: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export function ArtworkForm() {
  const { artworkId } = useParams();
  const isEditing = !!artworkId;
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const [formError, setFormError] = useState<string | null>(null);

  const { data: existing, isLoading: isLoadingExisting } = useQuery({
    queryKey: ["artwork", artworkId],
    queryFn: () => artworksApi.get(Number(artworkId)),
    enabled: isEditing,
  });

  const {
    register,
    handleSubmit,
    setError,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { title: "", description: "", medium: "", category: "", tags: "" },
  });

  useEffect(() => {
    if (existing?.artwork) {
      const a = existing.artwork;
      reset({
        title: a.title,
        description: a.description ?? "",
        medium: a.medium,
        category: a.category,
        tags: a.tags.join(", "),
      });
    }
  }, [existing, reset]);

  const mutation = useMutation({
    mutationFn: (values: FormValues) => {
      const tags = (values.tags ?? "").split(",").map((t) => t.trim()).filter(Boolean);
      const payload = {
        title: values.title,
        description: values.description,
        medium: values.medium,
        category: values.category,
        // On create: status defaults to "Not started", progress to 0.
        // These will be updated when the user adds their first progress entry.
        status: existing?.artwork.status ?? "Not started",
        progress: existing?.artwork.progress ?? 0,
        tags,
      };
      return isEditing
        ? artworksApi.update(Number(artworkId), payload)
        : artworksApi.create(payload);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["artworks"] });
      showToast(isEditing ? "Artwork updated" : "Artwork created — add your first progress photo!");
      navigate(`/app/artworks/${data.artwork.id}`);
    },
    onError: (err) => {
      if (err instanceof ApiError && err.fields) {
        for (const [field, message] of Object.entries(err.fields)) {
          if (field in schema.shape) setError(field as keyof FormValues, { message });
        }
        setFormError(err.message);
      } else {
        setFormError(err instanceof ApiError ? err.message : "Something went wrong. Please try again.");
      }
    },
  });

  if (isEditing && isLoadingExisting) {
    return <p style={{ color: "var(--color-text-muted)" }}>Loading artwork…</p>;
  }

  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <h1>{isEditing ? "Edit artwork" : "New artwork"}</h1>
        {!isEditing && (
          <p style={{ color: "var(--color-text-muted)", fontSize: "var(--fs-sm)", marginTop: "0.25rem" }}>
            Fill in the details — you'll upload your drawing when you add the first progress entry.
          </p>
        )}
      </div>

      <FormError message={formError} />

      <form onSubmit={handleSubmit((values) => mutation.mutate(values))} noValidate>
        <Input label="Title" error={errors.title?.message} {...register("title")} />

        <Textarea
          label="Description"
          rows={3}
          placeholder="What is this piece about?"
          error={errors.description?.message}
          {...register("description")}
        />

        <div className={styles.row}>
          <Select label="Medium" error={errors.medium?.message} {...register("medium")}>
            <option value="">Select…</option>
            {MEDIUMS.map((m) => <option key={m} value={m}>{m}</option>)}
          </Select>

          <Select label="Category" error={errors.category?.message} {...register("category")}>
            <option value="">Select…</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </Select>
        </div>

        <Input
          label="Tags"
          placeholder="portrait, fan art, graphite"
          error={errors.tags?.message}
          {...register("tags")}
        />

        <div className={styles.actions}>
          <Button type="submit" disabled={isSubmitting || mutation.isPending}>
            {mutation.isPending ? "Saving…" : isEditing ? "Save changes" : "Create artwork"}
          </Button>
          <Link to={isEditing ? `/app/artworks/${artworkId}` : "/app/gallery"}>
            <Button type="button" variant="secondary">Cancel</Button>
          </Link>
        </div>
      </form>
    </div>
  );
}
