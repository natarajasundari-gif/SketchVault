import { Routes, Route } from "react-router-dom";
import { AppLayout } from "./components/layout/AppLayout";
import { ProtectedRoute } from "./components/layout/ProtectedRoute";
import { PublicOnlyRoute } from "./components/layout/PublicOnlyRoute";

import { Landing } from "./pages/Landing/Landing";
import { Login } from "./pages/Auth/Login";
import { Register } from "./pages/Auth/Register";
import { ForgotPassword } from "./pages/Auth/ForgotPassword";
import { ResetPassword } from "./pages/Auth/ResetPassword";
import { Dashboard } from "./pages/Dashboard/Dashboard";
import { Gallery } from "./pages/Gallery/Gallery";
import { ArtworkDetail } from "./pages/ArtworkDetail/ArtworkDetail";
import { ArtworkForm } from "./pages/ArtworkForm/ArtworkForm";
import { Settings } from "./pages/Settings/Settings";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />

      <Route element={<PublicOnlyRoute />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
      </Route>

      <Route element={<ProtectedRoute />}>
        <Route path="/app" element={<AppLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="gallery" element={<Gallery />} />
          <Route path="artworks/new" element={<ArtworkForm />} />
          <Route path="artworks/:artworkId" element={<ArtworkDetail />} />
          <Route path="artworks/:artworkId/edit" element={<ArtworkForm />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Route>

      <Route path="*" element={<Landing />} />
    </Routes>
  );
}
