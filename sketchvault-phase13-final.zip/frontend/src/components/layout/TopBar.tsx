import { Link } from "react-router-dom";
import { ThemeToggle } from "../ui/ThemeToggle";
import { useAuth } from "../../context/AuthContext";
import styles from "./TopBar.module.css";

export function TopBar() {
  const { user } = useAuth();
  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()
    : "?";

  return (
    <header className={styles.topBar}>
      <div className={styles.brand}>
        <span className={styles.brandMark}>Sv</span>
        <span className={styles.brandName}>SketchVault</span>
      </div>
      <div className={styles.right}>
        <ThemeToggle />
        <Link to="/app/settings" className={styles.avatarLink} aria-label="Settings">
          {user?.avatar_url ? (
            <img src={user.avatar_url} alt={user.name} className={styles.avatarImg} />
          ) : (
            <div className={styles.avatarInitials}>{initials}</div>
          )}
        </Link>
      </div>
    </header>
  );
}
