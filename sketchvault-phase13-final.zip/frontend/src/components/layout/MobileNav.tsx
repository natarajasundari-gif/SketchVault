import { NavLink } from "react-router-dom";
import { LayoutGrid, Image, Plus, Settings } from "lucide-react";
import styles from "./MobileNav.module.css";

const items = [
  { to: "/app", label: "Studio", icon: LayoutGrid, end: true },
  { to: "/app/gallery", label: "Gallery", icon: Image },
  { to: "/app/artworks/new", label: "New", icon: Plus, isAction: true },
  { to: "/app/settings", label: "Settings", icon: Settings },
];

export function MobileNav() {
  return (
    <nav className={styles.nav} aria-label="Main">
      {items.map(({ to, label, icon: Icon, end, isAction }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          className={({ isActive }) =>
            [styles.link, isActive ? styles.active : "", isAction ? styles.action : ""]
              .filter(Boolean)
              .join(" ")
          }
        >
          <Icon size={isAction ? 20 : 19} strokeWidth={1.75} />
          <span>{label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
