import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

/** Keeps a logged-in user from landing back on /login or /register —
 * mirrors ProtectedRoute's isLoading handling so it doesn't flash a
 * redirect before the initial session check resolves. */
export function PublicOnlyRoute() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) return null;
  if (isAuthenticated) return <Navigate to="/app" replace />;

  return <Outlet />;
}
