import { NavLink, useNavigate } from "react-router-dom";
import { LayoutGrid, Image, Settings, Plus, LogOut } from "lucide-react";
import { ThemeToggle } from "../ui/ThemeToggle";
import { useAuth } from "../../context/AuthContext";
import styles from "./Sidebar.module.css";

const navItems = [
  { to: "/app", label: "Studio", icon: LayoutGrid, end: true },
  { to: "/app/gallery", label: "Gallery", icon: Image },
  { to: "/app/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/", { replace: true });
  };

  return (
    <aside className={styles.sidebar}>
      <div className={styles.brand}>
        <span className={styles.brandMark}>Sv</span>
        <span className={styles.brandName}>SketchVault</span>
      </div>

      <NavLink to="/app/artworks/new" className={styles.newArtwork}>
        <Plus size={17} strokeWidth={2} />
        New artwork
      </NavLink>

      <nav className={styles.nav} aria-label="Main">
        {navItems.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
          >
            <Icon size={18} strokeWidth={1.75} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className={styles.footer}>
        {user && (
          <div className={styles.userRow}>
            {user.avatar_url ? (
              <img src={user.avatar_url} alt={user.name} className={styles.userAvatar} />
            ) : (
              <div className={styles.userAvatarInitials}>
                {user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()}
              </div>
            )}
            <span className={styles.userName}>{user.name}</span>
            <button
              type="button"
              className={styles.logoutButton}
              onClick={handleLogout}
              aria-label="Log out"
              title="Log out"
            >
              <LogOut size={16} strokeWidth={1.75} />
            </button>
          </div>
        )}
        <ThemeToggle />
      </div>
    </aside>
  );
}
