import { useEffect, useState, useCallback } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";

import { progressApi, type ProgressEntry } from "../../api/progress";
import { ApiError } from "../../api/client";
import { Input } from "../ui/Input";
import { Textarea } from "../ui/Textarea";
import { Button } from "../ui/Button";
import { ImageUpload } from "../ui/ImageUpload";
import { CropPicker, type CropRect } from "../ui/CropPicker";
import { FormError } from "../feedback/FormError";
import { useToast } from "../ui/Toast";
import styles from "./ProgressModal.module.css";

const schema = z.object({
  stage: z.string().min(1, "Stage name is required"),
  progress: z.number().min(0).max(100),
  note: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

interface ProgressModalProps {
  artworkId: number;
  currentProgress: number;
  entry?: ProgressEntry;
  onClose: () => void;
}

export function ProgressModal({ artworkId, currentProgress, entry, onClose }: ProgressModalProps) {
  const isEditing = !!entry;
  const { showToast } = useToast();
  const queryClient = useQueryClient();

  const [image, setImage] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  const [crop, setCrop] = useState<CropRect | null>(entry?.crop ?? null);
  const [formError, setFormError] = useState<string | null>(null);

  // When a new file is picked, create a local preview URL for the CropPicker
  useEffect(() => {
    if (image) {
      const url = URL.createObjectURL(image);
      setImagePreviewUrl(url);
      setCrop(null); // reset crop for new image
      return () => URL.revokeObjectURL(url);
    } else {
      setImagePreviewUrl(null);
    }
  }, [image]);

  const onCropChange = useCallback((c: CropRect) => setCrop(c), []);

  const {
    register, handleSubmit, control, watch, setError, reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      stage: entry?.stage ?? "",
      progress: entry?.progress ?? currentProgress,
      note: entry?.note ?? "",
    },
  });

  useEffect(() => {
    if (entry) reset({ stage: entry.stage, progress: entry.progress, note: entry.note ?? "" });
  }, [entry, reset]);

  const progressValue = watch("progress");

  const mutation = useMutation({
    mutationFn: (values: FormValues) => {
      // Build FormData manually so we can include crop fields
      const form = new FormData();
      form.set("stage", values.stage);
      form.set("progress", String(values.progress));
      form.set("note", values.note ?? "");
      if (image) form.set("image", image);
      if (crop) {
        form.set("crop_cx", String(crop.cx));
        form.set("crop_cy", String(crop.cy));
        form.set("crop_w",  String(crop.w));
        form.set("crop_h",  String(crop.h));
      }

      if (isEditing) {
        return progressApi.updateRaw(artworkId, entry!.id, form);
      }
      return progressApi.addRaw(artworkId, form);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["progress", artworkId] });
      queryClient.invalidateQueries({ queryKey: ["artwork", String(artworkId)] });
      queryClient.invalidateQueries({ queryKey: ["artworks"] });
      showToast(isEditing ? "Progress entry updated" : "Progress entry added");
      onClose();
    },
    onError: (err) => {
      if (err instanceof ApiError && err.fields) {
        for (const [field, message] of Object.entries(err.fields)) {
          if (field === "stage" || field === "note") setError(field, { message });
          else if (field === "image") setFormError(message);
        }
      } else {
        setFormError(err instanceof ApiError ? err.message : "Something went wrong.");
      }
    },
  });

  // Which image to show in the crop picker:
  // - after picking a new file: the local blob URL
  // - while editing and no new file: the existing entry's image URL
  const cropSrc = imagePreviewUrl ?? (isEditing ? entry?.image_url : null);
  const showCrop = !!cropSrc;

  return (
    <div className={styles.overlay} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={styles.modal} role="dialog" aria-modal="true" aria-labelledby="pm-title">
        <div className={styles.header}>
          <h2 id="pm-title">{isEditing ? "Edit progress" : "Add progress"}</h2>
          <button className={styles.closeBtn} onClick={onClose} aria-label="Close">
            <X size={18} strokeWidth={2} />
          </button>
        </div>

        <FormError message={formError} />

        <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate>
          <div style={{ marginBottom: "var(--space-4)" }}>
            <ImageUpload
              label="Progress image"
              value={image}
              existingImageUrl={isEditing && !image ? entry?.image_url : undefined}
              onChange={setImage}
              required={!isEditing}
            />
          </div>

          {/* Crop picker appears once an image is loaded */}
          {showCrop && (
            <div style={{ marginBottom: "var(--space-4)" }}>
              <CropPicker
                src={cropSrc!}
                initial={crop ?? undefined}
                onChange={onCropChange}
              />
            </div>
          )}

          <Input
            label="Stage"
            placeholder="e.g. Initial sketch, Base shading, Final details…"
            error={errors.stage?.message}
            {...register("stage")}
          />

          <div style={{ marginBottom: "var(--space-4)" }}>
            <span className={styles.progressLabel}>Progress</span>
            <div className={styles.progressRow}>
              <Controller
                control={control}
                name="progress"
                render={({ field }) => (
                  <input
                    type="range" min={0} max={100}
                    className={styles.rangeInput}
                    value={field.value}
                    onChange={(e) => field.onChange(Number(e.target.value))}
                    aria-label="Progress percentage"
                  />
                )}
              />
              <span className={styles.progressValue}>{progressValue}%</span>
            </div>
          </div>

          <Textarea
            label="Note"
            placeholder="What did you work on? Any observations?"
            rows={3}
            error={errors.note?.message}
            {...register("note")}
          />

          <div className={styles.actions}>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending
                ? isEditing ? "Saving…" : "Adding…"
                : isEditing ? "Save changes" : "Add progress"}
            </Button>
            <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          </div>
        </form>
      </div>
    </div>
  );
}
