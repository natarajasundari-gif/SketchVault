import { Link } from "react-router-dom";
import { ImageIcon } from "lucide-react";
import type { Artwork } from "../../api/artworks";
import { cropToObjectPosition } from "../../utils/cropToPosition";
import styles from "./ArtworkCard.module.css";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function ArtworkCard({ artwork }: { artwork: Artwork }) {
  return (
    <Link to={`/app/artworks/${artwork.id}`} className={styles.card}>
      <div className={styles.imageWrap}>
        {artwork.cover_image_url ? (
          <img
            src={artwork.cover_image_url}
            alt=""
            className={styles.image}
            style={{ objectPosition: cropToObjectPosition(artwork.cover_crop) }}
          />
        ) : (
          <div className={styles.placeholderImage}>
            <ImageIcon size={32} strokeWidth={1.25} />
          </div>
        )}
        <div className={styles.progressBar}>
          <div className={styles.progressFill} style={{ width: `${artwork.progress}%` }} />
        </div>
      </div>
      <div className={styles.body}>
        <div className={styles.title}>{artwork.title}</div>
        <div className={styles.meta}>
          <span>{artwork.medium}</span>
          <span>Updated {formatDate(artwork.updated_at)}</span>
        </div>
        <span className={styles.statusBadge}>
          {artwork.status} · {artwork.progress}%
        </span>
        {artwork.tags.length > 0 && (
          <div className={styles.tags} style={{ marginTop: "0.6rem" }}>
            {artwork.tags.slice(0, 3).map((tag) => (
              <span key={tag} className={styles.tag}>
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </Link>
  );
}
