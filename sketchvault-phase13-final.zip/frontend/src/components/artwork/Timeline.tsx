import { useState } from "react";
import { Pencil, Trash2, X } from "lucide-react";
import type { ProgressEntry } from "../../api/progress";
import { Button } from "../ui/Button";
import { cropToObjectPosition } from "../../utils/cropToPosition";
import styles from "./Timeline.module.css";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString(undefined, {
    month: "short", day: "numeric", year: "numeric",
  });
}

interface TimelineProps {
  entries: ProgressEntry[];
  onEdit: (entry: ProgressEntry) => void;
  onDelete: (entry: ProgressEntry) => void;
}

export function Timeline({ entries, onEdit, onDelete }: TimelineProps) {
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);

  return (
    <>
      <div className={styles.timeline}>
        {entries.map((entry) => (
          <div key={entry.id} className={styles.entry}>
            {/* Timeline dot marker */}
            <div className={styles.timelineMarker} aria-hidden="true" />

            {/* Content card: image + metadata + actions */}
            <div className={styles.entryContent}>
              {/* Full-width image — tap to lightbox */}
              <div
                className={styles.entryImage}
                onClick={() => setLightboxUrl(entry.image_url)}
                role="button"
                aria-label={`View full-size: ${entry.stage}`}
              >
                <img
                  src={entry.image_url}
                  alt={`Progress: ${entry.stage}`}
                  style={{ objectPosition: cropToObjectPosition(entry.crop) }}
                />
                {/* Progress bar at bottom of image */}
                <div className={styles.imageProgressBar}>
                  <div
                    className={styles.imageProgressFill}
                    style={{ width: `${entry.progress}%` }}
                  />
                </div>
              </div>

              {/* Stage + progress pill + date */}
              <div className={styles.meta}>
                <span className={styles.stageBadge}>{entry.stage}</span>
                <span className={styles.progressPill}>{entry.progress}%</span>
                <span className={styles.date}>{formatDate(entry.created_at)}</span>
              </div>

              {/* Note (if present) */}
              {entry.note && (
                <p className={styles.note}>"{entry.note}"</p>
              )}

              {/* Edit / Delete */}
              <div className={styles.entryActions}>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<Pencil size={13} strokeWidth={2} />}
                  onClick={() => onEdit(entry)}
                >
                  Edit
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<Trash2 size={13} strokeWidth={2} />}
                  onClick={() => onDelete(entry)}
                >
                  Delete
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox */}
      {lightboxUrl && (
        <div
          className={styles.lightbox}
          onClick={() => setLightboxUrl(null)}
          role="dialog"
          aria-modal="true"
          aria-label="Full-size progress image"
        >
          <button
            className={styles.lightboxClose}
            onClick={() => setLightboxUrl(null)}
            aria-label="Close"
          >
            <X size={18} strokeWidth={2} />
          </button>
          <img
            src={lightboxUrl}
            alt="Progress detail"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </>
  );
}
