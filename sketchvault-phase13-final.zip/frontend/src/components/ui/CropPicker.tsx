/**
 * CropPicker
 *
 * Lets the user drag a resizable box over an image to mark the focal
 * area (e.g. the face of a portrait). No external crop library needed —
 * the box is drawn with CSS and moved with pointer-event listeners.
 *
 * All values are normalised 0–1 relative to the *rendered* image.
 * The caller receives { cx, cy, w, h } on every change, where
 * cx/cy is the box centre and w/h are the box dimensions.
 */
import { useRef, useState, useEffect, useCallback } from "react";
import styles from "./CropPicker.module.css";

export interface CropRect {
  cx: number;  // centre-x  0–1
  cy: number;  // centre-y  0–1
  w: number;   // width     0–1
  h: number;   // height    0–1
}

interface CropPickerProps {
  src: string;
  initial?: CropRect;
  onChange: (crop: CropRect) => void;
}

type Handle = "tl" | "tr" | "bl" | "br" | "move";

const MIN_SIZE = 0.1; // minimum box dimension in normalised units

export function CropPicker({ src, initial, onChange }: CropPickerProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const imgRef  = useRef<HTMLImageElement>(null);

  // Box in normalised 0–1 coords (relative to rendered image)
  const [box, setBox] = useState<CropRect>(
    initial ?? { cx: 0.5, cy: 0.5, w: 0.6, h: 0.6 }
  );

  // Emit on every change
  useEffect(() => { onChange(box); }, [box, onChange]);

  // Convert pointer event to normalised [0,1] coords inside the image

  const dragRef = useRef<{
    handle: Handle;
    startX: number; startY: number;
    startBox: CropRect;
  } | null>(null);

  const onPointerDown = useCallback((e: React.PointerEvent, handle: Handle) => {
    e.preventDefault();
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = {
      handle,
      startX: e.clientX,
      startY: e.clientY,
      startBox: { ...box },
    };
  }, [box]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (!dragRef.current) return;
      const img = imgRef.current;
      if (!img) return;
      const rect = img.getBoundingClientRect();
      const dx = (e.clientX - dragRef.current.startX) / rect.width;
      const dy = (e.clientY - dragRef.current.startY) / rect.height;
      const sb = dragRef.current.startBox;

      setBox((_prev) => {
        let { cx, cy, w, h } = sb;

        switch (dragRef.current!.handle) {
          case "move":
            cx = Math.max(w / 2, Math.min(1 - w / 2, sb.cx + dx));
            cy = Math.max(h / 2, Math.min(1 - h / 2, sb.cy + dy));
            break;
          case "br":
            w = Math.max(MIN_SIZE, Math.min(1 - (sb.cx - sb.w / 2), sb.w + dx * 2));
            h = Math.max(MIN_SIZE, Math.min(1 - (sb.cy - sb.h / 2), sb.h + dy * 2));
            break;
          case "tl":
            w = Math.max(MIN_SIZE, sb.w - dx * 2);
            h = Math.max(MIN_SIZE, sb.h - dy * 2);
            cx = sb.cx + (sb.w - w) / 2;
            cy = sb.cy + (sb.h - h) / 2;
            break;
          case "tr":
            w = Math.max(MIN_SIZE, sb.w + dx * 2);
            h = Math.max(MIN_SIZE, sb.h - dy * 2);
            cy = sb.cy + (sb.h - h) / 2;
            break;
          case "bl":
            w = Math.max(MIN_SIZE, sb.w - dx * 2);
            h = Math.max(MIN_SIZE, sb.h + dy * 2);
            cx = sb.cx + (sb.w - w) / 2;
            break;
        }

        // Clamp box inside image
        cx = Math.max(w / 2, Math.min(1 - w / 2, cx));
        cy = Math.max(h / 2, Math.min(1 - h / 2, cy));
        w  = Math.min(w, 1);
        h  = Math.min(h, 1);

        return { cx, cy, w, h };
      });
    };

    const onUp = () => { dragRef.current = null; };

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, []);

  // Pixel coords of the box (for CSS positioning)
  const boxLeft   = `${(box.cx - box.w / 2) * 100}%`;
  const boxTop    = `${(box.cy - box.h / 2) * 100}%`;
  const boxWidth  = `${box.w * 100}%`;
  const boxHeight = `${box.h * 100}%`;

  const dimL = `${(box.cx - box.w / 2) * 100}%`;
  const dimR = `${(1 - box.cx - box.w / 2) * 100}%`;
  const dimT = `${(box.cy - box.h / 2) * 100}%`;
  const dimB = `${(1 - box.cy - box.h / 2) * 100}%`;

  return (
    <div>
      <div ref={wrapRef} className={styles.wrap}>
        <img ref={imgRef} src={src} className={styles.img} alt="Crop preview" draggable={false} />

        {/* Dim overlays (four strips around the box) */}
        <div className={styles.dimTop}    style={{ top: 0, left: 0, right: 0, height: dimT }} />
        <div className={styles.dimBottom} style={{ bottom: 0, left: 0, right: 0, height: dimB }} />
        <div className={styles.dimLeft}   style={{ top: dimT, bottom: dimB, left: 0, width: dimL }} />
        <div className={styles.dimRight}  style={{ top: dimT, bottom: dimB, right: 0, width: dimR }} />

        {/* Crop box */}
        <div
          className={styles.cropBox}
          style={{ left: boxLeft, top: boxTop, width: boxWidth, height: boxHeight }}
          onPointerDown={(e) => onPointerDown(e, "move")}
        >
          {/* Rule-of-thirds grid */}
          <svg className={styles.grid} viewBox="0 0 100 100" preserveAspectRatio="none"
            style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            <line x1="33.3" y1="0" x2="33.3" y2="100" stroke="rgba(255,255,255,0.2)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
            <line x1="66.6" y1="0" x2="66.6" y2="100" stroke="rgba(255,255,255,0.2)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
            <line x1="0" y1="33.3" x2="100" y2="33.3" stroke="rgba(255,255,255,0.2)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
            <line x1="0" y1="66.6" x2="100" y2="66.6" stroke="rgba(255,255,255,0.2)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
          </svg>

          {/* Corner handles */}
          <div className={`${styles.handle} ${styles.tl}`} onPointerDown={(e) => onPointerDown(e, "tl")} />
          <div className={`${styles.handle} ${styles.tr}`} onPointerDown={(e) => onPointerDown(e, "tr")} />
          <div className={`${styles.handle} ${styles.bl}`} onPointerDown={(e) => onPointerDown(e, "bl")} />
          <div className={`${styles.handle} ${styles.br}`} onPointerDown={(e) => onPointerDown(e, "br")} />
        </div>
      </div>
      <p className={styles.hint}>Drag the box to frame the focal area · Drag corners to resize</p>
    </div>
  );
}
