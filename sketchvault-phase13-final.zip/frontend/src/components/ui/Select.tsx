import { forwardRef, useId, type SelectHTMLAttributes, type ReactNode } from "react";
import fieldStyles from "./Input.module.css";
import styles from "./FormControls.module.css";

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  error?: string;
  children: ReactNode;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, id, children, ...rest }, ref) => {
    const generatedId = useId();
    const selectId = id ?? generatedId;
    const errorId = `${selectId}-error`;

    return (
      <div className={fieldStyles.field}>
        <label className={fieldStyles.label} htmlFor={selectId}>
          {label}
        </label>
        <select
          id={selectId}
          ref={ref}
          className={`${styles.select} ${error ? fieldStyles.invalid : ""}`}
          aria-invalid={!!error}
          aria-describedby={error ? errorId : undefined}
          {...rest}
        >
          {children}
        </select>
        {error && (
          <span className={fieldStyles.errorText} id={errorId} role="alert">
            {error}
          </span>
        )}
      </div>
    );
  }
);
Select.displayName = "Select";
