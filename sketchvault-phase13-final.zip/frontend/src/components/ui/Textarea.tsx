import { forwardRef, useId, type TextareaHTMLAttributes } from "react";
import fieldStyles from "./Input.module.css";
import styles from "./FormControls.module.css";

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, id, ...rest }, ref) => {
    const generatedId = useId();
    const textareaId = id ?? generatedId;
    const errorId = `${textareaId}-error`;

    return (
      <div className={fieldStyles.field}>
        <label className={fieldStyles.label} htmlFor={textareaId}>
          {label}
        </label>
        <textarea
          id={textareaId}
          ref={ref}
          className={`${styles.textarea} ${error ? fieldStyles.invalid : ""}`}
          aria-invalid={!!error}
          aria-describedby={error ? errorId : undefined}
          {...rest}
        />
        {error && (
          <span className={fieldStyles.errorText} id={errorId} role="alert">
            {error}
          </span>
        )}
      </div>
    );
  }
);
Textarea.displayName = "Textarea";
