import { useRef, useState, type DragEvent } from "react";
import { ImagePlus, X } from "lucide-react";
import styles from "./ImageUpload.module.css";

const ACCEPTED_TYPES = ["image/png", "image/jpeg", "image/webp"];
const MAX_BYTES = 8 * 1024 * 1024; // matches backend MAX_CONTENT_LENGTH

interface ImageUploadProps {
  label: string;
  value: File | null;
  existingImageUrl?: string | null;
  onChange: (file: File | null) => void;
  required?: boolean;
}

export function ImageUpload({ label, value, existingImageUrl, onChange, required }: ImageUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const previewUrl = value ? URL.createObjectURL(value) : existingImageUrl ?? null;

  const validateAndSet = (file: File | null) => {
    if (!file) {
      onChange(null);
      return;
    }
    if (!ACCEPTED_TYPES.includes(file.type)) {
      setError("Please use a PNG, JPEG, or WEBP image.");
      return;
    }
    if (file.size > MAX_BYTES) {
      setError("That image is too large — please keep it under 8MB.");
      return;
    }
    setError(null);
    onChange(file);
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0] ?? null;
    validateAndSet(file);
  };

  if (previewUrl) {
    return (
      <div>
        <label className="visually-hidden">{label}{required ? " (required)" : ""}</label>
        <div className={styles.previewWrap}>
          <img src={previewUrl} alt="" className={styles.previewImage} />
          <button
            type="button"
            className={styles.removeButton}
            onClick={() => {
              onChange(null);
              setError(null);
              if (inputRef.current) inputRef.current.value = "";
            }}
            aria-label="Remove image"
          >
            <X size={16} strokeWidth={2} />
          </button>
        </div>
        {error && <span className={styles.errorText}>{error}</span>}
      </div>
    );
  }

  return (
    <div>
      <div
        className={`${styles.dropzone} ${isDragging ? styles.dragging : ""}`}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
        aria-label={label}
      >
        <ImagePlus size={28} strokeWidth={1.5} className={styles.icon} />
        <div>Drop an image here, or click to choose one</div>
        <span className={styles.hint}>PNG, JPEG, or WEBP — up to 8MB</span>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        style={{ display: "none" }}
        onChange={(e) => validateAndSet(e.target.files?.[0] ?? null)}
      />
      {error && <span className={styles.errorText}>{error}</span>}
    </div>
  );
}
