import styles from "./PhasePlaceholder.module.css";

interface PhasePlaceholderProps {
  title: string;
  note: string;
}

/** Marks a screen whose real implementation lands in a later phase,
 * so the routing/layout can be reviewed now without pretending a
 * feature exists before it's built. */
export function PhasePlaceholder({ title, note }: PhasePlaceholderProps) {
  return (
    <div className={styles.wrap}>
      <h2>{title}</h2>
      <p>{note}</p>
    </div>
  );
}
