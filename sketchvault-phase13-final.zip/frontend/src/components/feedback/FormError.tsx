import { AlertCircle } from "lucide-react";
import styles from "./FormError.module.css";

export function FormError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className={styles.banner} role="alert">
      <AlertCircle size={16} strokeWidth={2} style={{ flexShrink: 0, marginTop: "2px" }} />
      <span>{message}</span>
    </div>
  );
}
