import type { CropRect } from "../components/ui/CropPicker";

/**
 * Convert a CropRect's centre point to a CSS `object-position` value.
 * e.g. { cx: 0.3, cy: 0.2 } → "30% 20%"
 *
 * This makes the focal point visible inside any fixed-size container
 * (gallery card, detail header) without re-encoding the image.
 *
 * Falls back to "50% 50%" (centre) when no crop is provided.
 */
export function cropToObjectPosition(crop: CropRect | null | undefined): string {
  if (!crop) return "50% 50%";
  const x = Math.round(crop.cx * 100);
  const y = Math.round(crop.cy * 100);
  return `${x}% ${y}%`;
}
