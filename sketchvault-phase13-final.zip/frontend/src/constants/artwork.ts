export const MEDIUMS = [
  "Graphite",
  "Colored Pencil",
  "Charcoal",
  "Watercolor",
  "Acrylic",
  "Oil",
  "Digital",
  "Ink",
  "Markers",
  "Mixed Media",
  "Other",
];

export const CATEGORIES = [
  "Portrait",
  "Landscape",
  "Character Art",
  "Fan Art",
  "Still Life",
  "Abstract",
  "Illustration",
  "Other",
];

export const SORT_OPTIONS: { value: string; label: string }[] = [
  { value: "recent_updated", label: "Recently updated" },
  { value: "recent_created", label: "Recently created" },
  { value: "alphabetical", label: "Alphabetical" },
  { value: "progress", label: "Progress" },
];
