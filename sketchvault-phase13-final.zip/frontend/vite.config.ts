import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // All /api/* requests from the browser are forwarded to Flask.
      // This covers both JSON API calls AND static image responses from
      // /api/uploads/*, which <img src="..."> tags hit directly without
      // going through the fetch-based API client.
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
        // Cookies (JWT, CSRF) must flow through — don't strip credentials.
        secure: false,
      },
    },
  },
})
